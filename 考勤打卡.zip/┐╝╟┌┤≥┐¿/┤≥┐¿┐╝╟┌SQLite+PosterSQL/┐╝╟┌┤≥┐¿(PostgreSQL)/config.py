import os
from typing import Dict, Any
from datetime import timedelta, timezone


# 基础配置
class Config:
    # Bot 配置
    TOKEN = os.getenv("BOT_TOKEN", "8144712657:AAEU3edVjMs8kt9OC8jQiIZMnRErjSs1TPo")

    # 数据库配置 - 支持本地 SQLite 和 PostgreSQL
    DATABASE_URL = os.getenv("DATABASE_URL")

    # 如果没有提供 DATABASE_URL，使用 SQLite 作为回退
    if not DATABASE_URL:
        DATABASE_URL = "sqlite:///bot_data.db"
        print("⚠️  使用 SQLite 数据库进行本地开发")
    else:
        print("✅ 使用 PostgreSQL 数据库")

    # 文件配置
    BACKUP_DIR = "backups"

    # 管理员配置
    ADMINS = [8356418002, 87654321]

    # 性能配置优化
    SAVE_DELAY = 3.0
    MAX_CONCURRENT_LOCKS = 2000
    MAX_MEMORY_USERS = 5000
    CLEANUP_INTERVAL = 3600

    # 默认上下班时间配置
    DEFAULT_WORK_HOURS = {"work_start": "09:00", "work_end": "18:00"}

    # 默认活动配置
    DEFAULT_ACTIVITY_LIMITS = {
        "吃饭": {"max_times": 2, "time_limit": 30},
        "小厕": {"max_times": 5, "time_limit": 5},
        "大厕": {"max_times": 2, "time_limit": 15},
        "抽烟": {"max_times": 5, "time_limit": 10},
    }

    # 默认罚款
    DEFAULT_FINE_RATES = {
        "吃饭": {"10": 100, "30": 300},
        "小厕": {"5": 50, "10": 100},
        "大厕": {"15": 80, "30": 200},
        "抽烟": {"10": 200, "30": 500},
    }

    # 默认上下班罚款配置
    DEFAULT_WORK_FINE_RATES = {
        "work_start": {"60": 50, "120": 100, "180": 200, "240": 300, "max": 500},
        "work_end": {"60": 50, "120": 100, "180": 200, "240": 300, "max": 500},
    }

    # 自动导出推送开关配置
    AUTO_EXPORT_SETTINGS = {
        "enable_channel_push": True,
        "enable_group_push": True,
        "enable_admin_push": True,
    }

    # 每日重置时间配置
    DAILY_RESET_HOUR = 0
    DAILY_RESET_MINUTE = 0

    # 消息模板
    MESSAGES = {
        "welcome": "欢迎使用群打卡机器人！请点击下方按钮或直接输入活动名称打卡：",
        "no_activity": "❌ 没有找到正在进行的活动，请先打卡活动再回座。",
        "has_activity": "❌ 您当前有活动【{}】正在进行中，请先回座后才能开始新活动！",
        "no_permission": "❌ 你没有权限执行此操作",
        "max_times_reached": "❌ 您今日的{}次数已达到上限（{}次），无法再次打卡",
        "setchannel_usage": "❌ 用法：/setchannel <频道ID>\n频道ID格式如 -1001234567890",
        "setgroup_usage": "❌ 用法：/setgroup <群组ID>\n用于接收超时通知的群组ID",
        "set_usage": "❌ 用法：/set <用户ID> <活动> <时长分钟>",
        "reset_usage": "❌ 用法：/reset <用户ID>",
        "addactivity_usage": "❌ 用法：/addactivity <活动名> <max次数> <time_limit分钟>",
        "setresettime_usage": "❌ 用法：/setresettime <小时> <分钟>\n例如：/setresettime 0 0 表示每天0点重置",
        "setfine_usage": "❌ 用法：/setfine <活动名> <时间段> <金额>\n例如：/setfine 抽烟 10 200",
        "setfines_all_usage": "❌ 用法：/setfines_all <t1> <f1> [<t2> <f2> ...]\n例如：/setfines_all 10 100 30 300 60 1000",
        "setpush_usage": "❌ 用法：/setpush <channel|group|admin> <on|off>",
        "setworkfine_usage": "❌ 用法：/setworkfine <work_start|work_end> <时间段> <金额>",
    }


# 时区配置
beijing_tz = timezone(timedelta(hours=8))
