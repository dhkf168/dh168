# config.py - 异步重构版本配置
import os
from datetime import timedelta, timezone


# 时区配置 - 必须在类外部定义
beijing_tz = timezone(timedelta(hours=8))


# 基础配置
class Config:
    # Bot 配置
    TOKEN = os.getenv("BOT_TOKEN", "8144712657:AAEU3edVjMs8kt9OC8jQiIZMnRErjSs1TPo")

    # 数据库配置 - 支持本地 SQLite 和 PostgreSQL
    DATABASE_URL = os.getenv("DATABASE_URL")

    # 如果没有提供 DATABASE_URL，使用 SQLite 作为回退
    if not DATABASE_URL:
        DATABASE_URL = "sqlite:///bot_data.db"
        print("⚠️  使用 SQLite 数据库进行本地开发")
    else:
        print("✅ 使用 PostgreSQL 数据库")

    # 数据库连接池高级配置 - 用于 CompleteAsyncDatabase
    DB_MIN_CONNECTIONS = int(os.getenv("DB_MIN_CONNECTIONS", "2"))
    DB_MAX_CONNECTIONS = int(os.getenv("DB_MAX_CONNECTIONS", "20"))
    DB_CONNECTION_TIMEOUT = int(os.getenv("DB_CONNECTION_TIMEOUT", "30"))
    DB_POOL_RECYCLE = int(os.getenv("DB_POOL_RECYCLE", "3600"))

    # 数据库健康检查配置
    DB_HEALTH_CHECK_ENABLED = os.getenv("DB_HEALTH_CHECK_ENABLED", "true").lower() == "true"
    DB_HEARTBEAT_INTERVAL = int(os.getenv("DB_HEARTBEAT_INTERVAL", "300"))
    DB_CONNECTION_MAX_AGE = int(os.getenv("DB_CONNECTION_MAX_AGE", "3600"))

    # 异步数据库连接池配置 - 兼容 CompleteAsyncDatabase
    DATABASE_POOL_SETTINGS = {
        "min_size": DB_MIN_CONNECTIONS,
        "max_size": DB_MAX_CONNECTIONS,
        "command_timeout": DB_CONNECTION_TIMEOUT,
        "max_inactive_connection_lifetime": DB_POOL_RECYCLE,
        # 新增 CompleteAsyncDatabase 专用配置
        "health_check_enabled": DB_HEALTH_CHECK_ENABLED,
        "heartbeat_interval": DB_HEARTBEAT_INTERVAL,
        "connection_max_age": DB_CONNECTION_MAX_AGE,
    }

    # SQLite 配置
    SQLITE_JOURNAL_MODE = "WAL"  # 使用 WAL 模式提高并发性能
    SQLITE_SYNCHRONOUS = "NORMAL"

    # 文件配置
    BACKUP_DIR = "backups"

    # 确保备份目录存在
    os.makedirs(BACKUP_DIR, exist_ok=True)

    # 管理员配置
    ADMIN_IDS = os.getenv("ADMIN_IDS", "8356418002,6607669683")
    ADMINS = [int(x.strip()) for x in ADMIN_IDS.split(",") if x.strip()]

    # 性能配置优化 - 异步版本可以设置更高的并发限制
    SAVE_DELAY = 3.0
    MAX_CONCURRENT_LOCKS = 5000  # 异步版本可以支持更多并发锁
    MAX_MEMORY_USERS = 10000  # 异步版本可以缓存更多用户数据
    CLEANUP_INTERVAL = 3600  # 内存清理间隔（秒）

    # 数据保留配置
    DATA_RETENTION_DAYS = 35  # 保留35天（一个月+缓冲）
    MONTHLY_BACKUP_DAYS = 365  # 月度备份保留一年

    # 默认上下班时间配置
    DEFAULT_WORK_HOURS = {"work_start": "09:00", "work_end": "18:00"}

    # 默认活动配置
    DEFAULT_ACTIVITY_LIMITS = {
        "吃饭": {"max_times": 2, "time_limit": 30},
        "小厕": {"max_times": 5, "time_limit": 5},
        "大厕": {"max_times": 2, "time_limit": 15},
        "抽烟": {"max_times": 5, "time_limit": 10},
    }

    # 默认罚款
    DEFAULT_FINE_RATES = {
        "吃饭": {"10": 100, "30": 300},
        "小厕": {"5": 50, "10": 100},
        "大厕": {"15": 80, "30": 200},
        "抽烟": {"10": 200, "30": 500},
    }

    # 默认上下班罚款配置
    DEFAULT_WORK_FINE_RATES = {
        "work_start": {"60": 50, "120": 100, "180": 200, "240": 300, "max": 500},
        "work_end": {"60": 50, "120": 100, "180": 200, "240": 300, "max": 500},
    }

    # 自动导出推送开关配置
    AUTO_EXPORT_SETTINGS = {
        "enable_channel_push": True,
        "enable_group_push": True,
        "enable_admin_push": True,
        "monthly_auto_export": True,  # 月度自动导出
    }

    # 每日重置时间配置
    DAILY_RESET_HOUR = 0
    DAILY_RESET_MINUTE = 0

    # 异步任务配置
    ASYNC_TASK_CONFIG = {
        "max_concurrent_tasks": 100,  # 最大并发任务数
        "task_timeout": 300,  # 任务超时时间（秒）
        "retry_attempts": 3,  # 重试次数
        "retry_delay": 5,  # 重试延迟（秒）
    }

    # 内存管理配置
    MEMORY_MANAGEMENT = {
        "max_memory_mb": 400,  # 最大内存使用（MB）
        "gc_threshold": (700, 10, 10),  # GC 阈值
        "cleanup_batch_size": 100,  # 清理批次大小
    }

    # 日志配置
    LOGGING_CONFIG = {
        "level": "INFO",
        "format": "%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s",
        "max_file_size_mb": 10,
        "backup_count": 5,
    }

    # 导出配置
    EXPORT_CONFIG = {
        "batch_size": 50,  # 分批处理大小
        "max_file_size_mb": 20,  # 最大文件大小
        "temp_file_cleanup_delay": 300,  # 临时文件清理延迟
    }

    # 消息模板
    MESSAGES = {
        "welcome": "欢迎使用群打卡机器人！请点击下方按钮或直接输入活动名称打卡：",
        "no_activity": "❌ 没有找到正在进行的活动，请先打卡活动再回座。",
        "has_activity": "❌ 您当前有活动【{}】正在进行中，请先回座后才能开始新活动！",
        "no_permission": "❌ 你没有权限执行此操作",
        "max_times_reached": "❌ 您今日的{}次数已达到上限（{}次），无法再次打卡",
        "setchannel_usage": "❌ 用法：/setchannel <频道ID>\n频道ID格式如 -1001234567890",
        "setgroup_usage": "❌ 用法：/setgroup <群组ID>\n用于接收超时通知的群组ID",
        "set_usage": "❌ 用法：/set <用户ID> <活动> <时长分钟>",
        "reset_usage": "❌ 用法：/reset <用户ID>",
        "addactivity_usage": "❌ 用法：/addactivity <活动名> <max次数> <time_limit分钟>",
        "setresettime_usage": "❌ 用法：/setresettime <小时> <分钟>\n例如：/setresettime 0 0 表示每天0点重置",
        "setfine_usage": "❌ 用法：/setfine <活动名> <时间段> <金额>\n例如：/setfine 抽烟 10 200",
        "setfines_all_usage": "❌ 用法：/setfines_all <t1> <f1> [<t2> <f2> ...]\n例如：/setfines_all 10 100 30 300 60 1000",
        "setpush_usage": "❌ 用法：/setpush <channel|group|admin> <on|off>",
        "setworkfine_usage": "❌ 用法：/setworkfine <work_start|work_end> <时间段> <金额>",
        # 异步相关消息
        "async_processing": "⏳ 正在处理中，请稍候...",
        "async_timeout": "⏰ 处理超时，请稍后重试",
        "async_error": "❌ 处理过程中出现错误，请稍后重试",
        # 数据库相关消息
        "db_connection_error": "❌ 数据库连接失败，请检查配置",
        "db_query_timeout": "⏰ 数据库查询超时，请稍后重试",
        # 导出相关消息
        "export_started": "📤 开始导出数据...",
        "export_completed": "✅ 数据导出完成",
        "export_failed": "❌ 数据导出失败",
        "export_no_data": "⚠️ 没有数据需要导出",
        # 月度报告消息
        "monthly_report_generating": "📊 正在生成月度报告...",
        "monthly_report_completed": "✅ 月度报告生成完成",
        "monthly_report_no_data": "⚠️ 该月份没有数据需要报告",
        # 系统维护消息
        "maintenance_cleanup": "🧹 正在清理系统数据...",
        "maintenance_completed": "✅ 系统维护完成",
    }

    # 错误代码
    ERROR_CODES = {
        "DB_CONNECTION_FAILED": 1001,
        "DB_QUERY_TIMEOUT": 1002,
        "DB_TRANSACTION_FAILED": 1003,
        "ASYNC_TASK_TIMEOUT": 2001,
        "ASYNC_TASK_CANCELLED": 2002,
        "MEMORY_LIMIT_EXCEEDED": 3001,
        "FILE_OPERATION_FAILED": 4001,
        "NETWORK_ERROR": 5001,
        "PERMISSION_DENIED": 6001,
    }

    # 功能开关
    FEATURE_FLAGS = {
        "enable_async_processing": True,  # 启用异步处理
        "enable_memory_management": True,  # 启用内存管理
        "enable_auto_cleanup": True,  # 启用自动清理
        "enable_performance_monitoring": True,  # 启用性能监控
        "enable_error_tracking": True,  # 启用错误追踪
        "enable_health_checks": True,  # 启用健康检查
    }

    # 健康检查配置
    HEALTH_CHECK_CONFIG = {
        "check_interval": 60,  # 检查间隔（秒）
        "timeout": 10,  # 超时时间（秒）
        "retry_count": 3,  # 重试次数
        "critical_memory_usage": 0.8,  # 关键内存使用率
    }

    # 性能监控配置
    PERFORMANCE_MONITORING = {
        "enable_metrics": True,  # 启用指标收集
        "metrics_interval": 60,  # 指标收集间隔
        "slow_query_threshold": 5.0,  # 慢查询阈值（秒）
        "high_memory_threshold": 0.7,  # 高内存使用阈值
    }


# 配置验证
try:
    # 验证必要的配置
    if not Config.TOKEN:
        raise ValueError("BOT_TOKEN 未设置")
    if not Config.ADMINS:
        raise ValueError("ADMIN_IDS 未设置有效的管理员ID")

    # 验证数据库URL格式
    if Config.DATABASE_URL and Config.DATABASE_URL.startswith("postgresql"):
        # PostgreSQL URL 验证
        required_parts = ["postgresql://", "@", "/"]
        for part in required_parts:
            if part not in Config.DATABASE_URL:
                raise ValueError(f"PostgreSQL 数据库URL格式不正确，缺少: {part}")
    elif Config.DATABASE_URL and Config.DATABASE_URL.startswith("sqlite:///"):
        # SQLite URL 验证
        db_path = Config.DATABASE_URL.replace("sqlite:///", "")
        if not db_path:
            raise ValueError("SQLite 数据库路径不能为空")

    # 验证数值配置
    if Config.DB_MIN_CONNECTIONS < 1:
        raise ValueError("数据库连接池最小连接数必须大于0")
    if Config.DB_MAX_CONNECTIONS < Config.DB_MIN_CONNECTIONS:
        raise ValueError("数据库连接池最大连接数必须大于等于最小连接数")

    if Config.ASYNC_TASK_CONFIG["max_concurrent_tasks"] < 1:
        raise ValueError("最大并发任务数必须大于0")

    if Config.MEMORY_MANAGEMENT["max_memory_mb"] < 100:
        raise ValueError("最大内存限制必须至少100MB")

    # 验证新增的数据库配置
    if Config.DB_CONNECTION_TIMEOUT < 1:
        raise ValueError("数据库连接超时必须大于0")
    if Config.DB_POOL_RECYCLE < 60:
        raise ValueError("数据库连接回收时间必须至少60秒")
    if Config.DB_HEARTBEAT_INTERVAL < 30:
        raise ValueError("数据库心跳检查间隔必须至少30秒")
    if Config.DB_CONNECTION_MAX_AGE < 300:
        raise ValueError("数据库连接最大寿命必须至少300秒")

    print("✅ 配置验证通过")

except ValueError as e:
    print(f"❌ 配置错误: {e}")
    exit(1)
except Exception as e:
    print(f"❌ 配置验证过程中出现未知错误: {e}")
    exit(1)


# 环境相关工具函数
class EnvUtils:
    """环境工具类"""

    @staticmethod
    def is_production():
        """检查是否为生产环境"""
        return os.getenv("ENVIRONMENT", "development").lower() == "production"

    @staticmethod
    def is_development():
        """检查是否为开发环境"""
        return os.getenv("ENVIRONMENT", "development").lower() == "development"

    @staticmethod
    def get_environment():
        """获取当前环境"""
        return os.getenv("ENVIRONMENT", "development")

    @staticmethod
    def should_enable_debug():
        """是否启用调试模式"""
        return os.getenv("DEBUG", "false").lower() == "true"

    @staticmethod
    def get_log_level():
        """获取日志级别"""
        if EnvUtils.should_enable_debug():
            return "DEBUG"
        return Config.LOGGING_CONFIG["level"]


# 性能配置工具
class PerformanceConfig:
    """性能配置工具类"""

    @staticmethod
    def get_database_pool_settings():
        """获取数据库连接池设置（根据环境调整）"""
        base_settings = Config.DATABASE_POOL_SETTINGS.copy()

        if EnvUtils.is_production():
            # 生产环境使用更高的连接数
            base_settings["min_size"] = max(5, Config.DB_MIN_CONNECTIONS)
            base_settings["max_size"] = max(30, Config.DB_MAX_CONNECTIONS)
        elif EnvUtils.is_development():
            # 开发环境使用较低的连接数
            base_settings["min_size"] = min(1, Config.DB_MIN_CONNECTIONS)
            base_settings["max_size"] = min(10, Config.DB_MAX_CONNECTIONS)

        return base_settings

    @staticmethod
    def get_async_task_config():
        """获取异步任务配置（根据环境调整）"""
        base_config = Config.ASYNC_TASK_CONFIG.copy()

        if EnvUtils.is_production():
            base_config["max_concurrent_tasks"] = 200
        elif EnvUtils.is_development():
            base_config["max_concurrent_tasks"] = 50

        return base_config

    @staticmethod
    def get_memory_limits():
        """获取内存限制（根据环境调整）"""
        base_limits = Config.MEMORY_MANAGEMENT.copy()

        # 从环境变量读取内存限制
        env_memory = os.getenv("MAX_MEMORY_MB")
        if env_memory:
            try:
                base_limits["max_memory_mb"] = int(env_memory)
            except ValueError:
                print(f"⚠️ 无效的内存限制配置: {env_memory}，使用默认值")

        return base_limits

    @staticmethod
    def get_database_health_config():
        """获取数据库健康检查配置（根据环境调整）"""
        health_config = {
            "health_check_enabled": Config.DB_HEALTH_CHECK_ENABLED,
            "heartbeat_interval": Config.DB_HEARTBEAT_INTERVAL,
            "connection_max_age": Config.DB_CONNECTION_MAX_AGE,
        }

        if EnvUtils.is_production():
            # 生产环境更频繁的健康检查
            health_config["heartbeat_interval"] = min(180, Config.DB_HEARTBEAT_INTERVAL)
        elif EnvUtils.is_development():
            # 开发环境减少健康检查频率
            health_config["heartbeat_interval"] = max(600, Config.DB_HEARTBEAT_INTERVAL)

        return health_config


# 配置打印（启动时显示重要配置）
def print_startup_config():
    """打印启动配置"""
    print("🚀 机器人启动配置:")
    print(f"   环境: {EnvUtils.get_environment()}")
    print(f"   调试模式: {EnvUtils.should_enable_debug()}")
    print(f"   日志级别: {EnvUtils.get_log_level()}")
    print(
        f"   数据库类型: {'PostgreSQL' if Config.DATABASE_URL and Config.DATABASE_URL.startswith('postgresql') else 'SQLite'}"
    )
    print(f"   管理员数量: {len(Config.ADMINS)}")
    print(f"   活动数量: {len(Config.DEFAULT_ACTIVITY_LIMITS)}")

    # 性能配置
    perf_config = PerformanceConfig.get_database_pool_settings()
    print(f"   数据库连接池: {perf_config['min_size']}-{perf_config['max_size']}")
    print(f"   连接超时: {Config.DB_CONNECTION_TIMEOUT}秒")
    print(f"   连接回收: {Config.DB_POOL_RECYCLE}秒")
    print(f"   健康检查: {'启用' if Config.DB_HEALTH_CHECK_ENABLED else '禁用'}")
    print(f"   心跳间隔: {Config.DB_HEARTBEAT_INTERVAL}秒")

    task_config = PerformanceConfig.get_async_task_config()
    print(f"   最大并发任务: {task_config['max_concurrent_tasks']}")

    memory_limits = PerformanceConfig.get_memory_limits()
    print(f"   内存限制: {memory_limits['max_memory_mb']}MB")


# 启动时打印配置
if __name__ == "__main__":
    print_startup_config()
else:
    # 模块导入时也打印配置（便于调试）
    import sys

    if "gunicorn" not in sys.modules and "uwsgi" not in sys.modules:
        print_startup_config()