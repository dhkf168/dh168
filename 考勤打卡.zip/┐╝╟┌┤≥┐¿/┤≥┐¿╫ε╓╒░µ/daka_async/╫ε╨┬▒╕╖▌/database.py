# database.py - 完整异步重构优化版本
import logging
import asyncio
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from config import Config
import os
import asyncpg
import aiosqlite
from asyncpg.pool import Pool
from performance import global_cache, track_performance, with_retry


logger = logging.getLogger("GroupCheckInBot")

class OptimizedAsyncDatabase:
    def __init__(self, database_url: str = None):
        self.database_url = database_url or Config.DATABASE_URL
        self.pool: Optional[Pool] = None
        self.db_type = (
            "postgresql"
            if self.database_url and self.database_url.startswith("postgresql")
            else "sqlite"
        )
        self.db_path = "bot_data.db"
        self.cache = global_cache
        self._initialized = False

    @track_performance("database_initialize")
    async def initialize(self):
        """异步初始化数据库"""
        if self._initialized:
            return
            
        try:
            if self.db_type == "postgresql":
                await self._init_postgresql()
            else:
                await self._init_sqlite()

            await self.init_database()
            logger.info(f"✅ 异步数据库初始化完成 - 类型: {self.db_type}")
            self._initialized = True
        except Exception as e:
            logger.error(f"❌ 数据库初始化失败: {e}")
            raise

    async def _init_postgresql(self):
        """初始化 PostgreSQL 连接池"""
        try:
            self.pool = await asyncpg.create_pool(
                self.database_url, 
                min_size=Config.DB_MIN_CONNECTIONS,
                max_size=Config.DB_MAX_CONNECTIONS, 
                command_timeout=Config.DB_CONNECTION_TIMEOUT
            )
            logger.info("✅ PostgreSQL 异步连接池创建成功")
        except Exception as e:
            logger.error(f"❌ PostgreSQL 连接池创建失败: {e}")
            raise

    async def _init_sqlite(self):
        """初始化 SQLite 连接"""
        if self.database_url and self.database_url.startswith("sqlite:///"):
            self.db_path = self.database_url.replace("sqlite:///", "")

        async with aiosqlite.connect(self.db_path) as conn:
            await conn.execute("PRAGMA journal_mode=WAL")
            await conn.execute("PRAGMA synchronous=NORMAL")
            await conn.execute("SELECT 1")
        logger.info(f"✅ SQLite 数据库连接就绪: {self.db_path}")

    async def get_connection(self):
        """获取数据库连接"""
        if self.db_type == "postgresql":
            return await self.pool.acquire()
        else:
            conn = await aiosqlite.connect(self.db_path)
            conn.row_factory = aiosqlite.Row
            return conn

    async def release_connection(self, conn):
        """释放数据库连接"""
        if self.db_type == "postgresql":
            await self.pool.release(conn)
        else:
            await conn.close()

    async def execute_query(
        self,
        conn,
        query: str,
        params: tuple = None,
        fetchone: bool = False,
        fetchall: bool = False,
    ):
        """统一执行查询 - 优化版本"""
        try:
            if self.db_type == "postgresql":
                if fetchone:
                    result = (
                        await conn.fetchrow(query, *params)
                        if params
                        else await conn.fetchrow(query)
                    )
                    return dict(result) if result else None
                elif fetchall:
                    results = (
                        await conn.fetch(query, *params)
                        if params
                        else await conn.fetch(query)
                    )
                    return [dict(row) for row in results] if results else []
                else:
                    return (
                        await conn.execute(query, *params)
                        if params
                        else await conn.execute(query)
                    )
            else:
                # SQLite 处理
                cursor = await conn.execute(query, params or ())
                if fetchone:
                    result = await cursor.fetchone()
                    await cursor.close()
                    return dict(result) if result else None
                elif fetchall:
                    results = await cursor.fetchall()
                    await cursor.close()
                    return [dict(row) for row in results] if results else []
                else:
                    await conn.commit()
                    return cursor
        except Exception as e:
            logger.error(f"数据库查询错误: {e}, 查询: {query}, 参数: {params}")
            raise

    async def init_database(self):
        """初始化数据库表 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                tables = self._get_postgresql_tables()
            else:
                tables = self._get_sqlite_tables()

            for table_sql in tables:
                await self.execute_query(conn, table_sql)

            # 初始化默认数据
            await self._initialize_default_data(conn)
            await conn.commit()

        finally:
            await self.release_connection(conn)

        # 添加性能索引
        await self._create_indexes()

    def _get_postgresql_tables(self):
        """PostgreSQL 表结构"""
        return [
            """
            CREATE TABLE IF NOT EXISTS groups (
                chat_id BIGINT PRIMARY KEY,
                channel_id BIGINT,
                notification_group_id BIGINT,
                reset_hour INTEGER DEFAULT 0,
                reset_minute INTEGER DEFAULT 0,
                work_start_time TEXT DEFAULT '09:00',
                work_end_time TEXT DEFAULT '18:00',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                chat_id BIGINT,
                user_id BIGINT,
                nickname TEXT,
                current_activity TEXT,
                activity_start_time TEXT,
                total_accumulated_time INTEGER DEFAULT 0,
                total_activity_count INTEGER DEFAULT 0,
                total_fines INTEGER DEFAULT 0,
                overtime_count INTEGER DEFAULT 0,
                total_overtime_time INTEGER DEFAULT 0,
                last_updated DATE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(chat_id, user_id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS user_activities (
                id SERIAL PRIMARY KEY,
                chat_id BIGINT,
                user_id BIGINT,
                activity_date DATE,
                activity_name TEXT,
                activity_count INTEGER DEFAULT 0,
                accumulated_time INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(chat_id, user_id, activity_date, activity_name)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS work_records (
                id SERIAL PRIMARY KEY,
                chat_id BIGINT,
                user_id BIGINT,
                record_date DATE,
                checkin_type TEXT,
                checkin_time TEXT,
                status TEXT,
                time_diff_minutes REAL,
                fine_amount INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(chat_id, user_id, record_date, checkin_type)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS activity_configs (
                activity_name TEXT PRIMARY KEY,
                max_times INTEGER,
                time_limit INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS fine_configs (
                id SERIAL PRIMARY KEY,
                activity_name TEXT,
                time_segment TEXT,
                fine_amount INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(activity_name, time_segment)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS work_fine_configs (
                id SERIAL PRIMARY KEY,
                checkin_type TEXT,
                time_segment TEXT,
                fine_amount INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(checkin_type, time_segment)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS push_settings (
                setting_key TEXT PRIMARY KEY,
                setting_value INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """,
        ]

    def _get_sqlite_tables(self):
        """SQLite 表结构"""
        return [
            """
            CREATE TABLE IF NOT EXISTS groups (
                chat_id INTEGER PRIMARY KEY,
                channel_id INTEGER,
                notification_group_id INTEGER,
                reset_hour INTEGER DEFAULT 0,
                reset_minute INTEGER DEFAULT 0,
                work_start_time TEXT DEFAULT '09:00',
                work_end_time TEXT DEFAULT '18:00',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER,
                user_id INTEGER,
                nickname TEXT,
                current_activity TEXT,
                activity_start_time TEXT,
                total_accumulated_time INTEGER DEFAULT 0,
                total_activity_count INTEGER DEFAULT 0,
                total_fines INTEGER DEFAULT 0,
                overtime_count INTEGER DEFAULT 0,
                total_overtime_time INTEGER DEFAULT 0,
                last_updated DATE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(chat_id, user_id)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS user_activities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER,
                user_id INTEGER,
                activity_date DATE,
                activity_name TEXT,
                activity_count INTEGER DEFAULT 0,
                accumulated_time INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(chat_id, user_id, activity_date, activity_name)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS work_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER,
                user_id INTEGER,
                record_date DATE,
                checkin_type TEXT,
                checkin_time TEXT,
                status TEXT,
                time_diff_minutes REAL,
                fine_amount INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(chat_id, user_id, record_date, checkin_type)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS activity_configs (
                activity_name TEXT PRIMARY KEY,
                max_times INTEGER,
                time_limit INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS fine_configs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                activity_name TEXT,
                time_segment TEXT,
                fine_amount INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(activity_name, time_segment)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS work_fine_configs (
                checkin_type TEXT,
                time_segment TEXT,
                fine_amount INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(checkin_type, time_segment)
            )
            """,
            """
            CREATE TABLE IF NOT EXISTS push_settings (
                setting_key TEXT PRIMARY KEY,
                setting_value INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """,
        ]

    async def _initialize_default_data(self, conn):
        """初始化默认数据 - 优化版本"""
        # 初始化活动配置
        for activity, limits in Config.DEFAULT_ACTIVITY_LIMITS.items():
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    "INSERT INTO activity_configs (activity_name, max_times, time_limit) VALUES ($1, $2, $3) ON CONFLICT (activity_name) DO NOTHING",
                    (activity, limits["max_times"], limits["time_limit"]),
                )
            else:
                await self.execute_query(
                    conn,
                    "INSERT OR IGNORE INTO activity_configs (activity_name, max_times, time_limit) VALUES (?, ?, ?)",
                    (activity, limits["max_times"], limits["time_limit"]),
                )

        # 初始化罚款配置
        for activity, fines in Config.DEFAULT_FINE_RATES.items():
            for time_segment, amount in fines.items():
                if self.db_type == "postgresql":
                    await self.execute_query(
                        conn,
                        "INSERT INTO fine_configs (activity_name, time_segment, fine_amount) VALUES ($1, $2, $3) ON CONFLICT (activity_name, time_segment) DO NOTHING",
                        (activity, time_segment, amount),
                    )
                else:
                    await self.execute_query(
                        conn,
                        "INSERT OR IGNORE INTO fine_configs (activity_name, time_segment, fine_amount) VALUES (?, ?, ?)",
                        (activity, time_segment, amount),
                    )

        # 初始化上下班罚款配置
        for checkin_type, fines in Config.DEFAULT_WORK_FINE_RATES.items():
            for time_segment, amount in fines.items():
                if self.db_type == "postgresql":
                    await self.execute_query(
                        conn,
                        "INSERT INTO work_fine_configs (checkin_type, time_segment, fine_amount) VALUES ($1, $2, $3) ON CONFLICT (checkin_type, time_segment) DO NOTHING",
                        (checkin_type, time_segment, amount),
                    )
                else:
                    await self.execute_query(
                        conn,
                        "INSERT OR IGNORE INTO work_fine_configs (checkin_type, time_segment, fine_amount) VALUES (?, ?, ?)",
                        (checkin_type, time_segment, amount),
                    )

        # 初始化推送设置
        for key, value in Config.AUTO_EXPORT_SETTINGS.items():
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    "INSERT INTO push_settings (setting_key, setting_value) VALUES ($1, $2) ON CONFLICT (setting_key) DO NOTHING",
                    (key, 1 if value else 0),
                )
            else:
                await self.execute_query(
                    conn,
                    "INSERT OR IGNORE INTO push_settings (setting_key, setting_value) VALUES (?, ?)",
                    (key, 1 if value else 0),
                )

    async def _create_indexes(self):
        """创建必要的索引 - 优化版本"""
        try:
            indexes = [
                "CREATE INDEX IF NOT EXISTS idx_user_activities_main ON user_activities (chat_id, user_id, activity_date)",
                "CREATE INDEX IF NOT EXISTS idx_user_activities_activity ON user_activities (activity_name)",
                "CREATE INDEX IF NOT EXISTS idx_work_records_main ON work_records (chat_id, user_id, record_date)",
                "CREATE INDEX IF NOT EXISTS idx_users_main ON users (chat_id, user_id)",
                "CREATE INDEX IF NOT EXISTS idx_users_updated ON users (last_updated)",
                "CREATE INDEX IF NOT EXISTS idx_user_activities_date ON user_activities (activity_date)",
                "CREATE INDEX IF NOT EXISTS idx_work_records_date ON work_records (record_date)",
            ]

            conn = await self.get_connection()
            try:
                for index_sql in indexes:
                    try:
                        await self.execute_query(conn, index_sql)
                    except Exception as e:
                        logger.warning(f"创建索引失败: {e}")
                await conn.commit()
            finally:
                await self.release_connection(conn)
        except Exception as e:
            logger.error(f"创建索引时发生错误: {e}")

    # ========== 工具函数 ==========
    def format_seconds_to_hms(self, seconds: int) -> str:
        """将秒数格式化为小时:分钟:秒的字符串"""
        if seconds is None:
            return "0秒"

        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60

        if hours > 0:
            return f"{hours}小时{minutes}分{secs}秒"
        elif minutes > 0:
            return f"{minutes}分{secs}秒"
        else:
            return f"{secs}秒"

    def format_minutes_to_hm(self, minutes: float) -> str:
        """将分钟数格式化为小时:分钟的字符串"""
        if minutes is None:
            return "0小时0分钟"

        total_seconds = int(minutes * 60)
        hours = total_seconds // 3600
        mins = (total_seconds % 3600) // 60
        secs = total_seconds % 60

        if hours > 0:
            return f"{hours}小时{mins}分{secs}秒"
        elif mins > 0:
            return f"{mins}分{secs}秒"
        else:
            return f"{secs}秒"

    # ========== 缓存优化方法 ==========

    async def get_user_cached(self, chat_id: int, user_id: int) -> Optional[Dict]:
        """带缓存的获取用户数据"""
        cache_key = f"user:{chat_id}:{user_id}"
        cached = await self.cache.get(cache_key)
        if cached is not None:
            return cached
            
        result = await self.get_user(chat_id, user_id)
        if result:
            await self.cache.set(cache_key, result, ttl=30)
        return result

    async def get_activity_limits_cached(self) -> Dict:
        """带缓存的获取活动限制"""
        cache_key = "activity_limits"
        cached = await self.cache.get(cache_key)
        if cached is not None:
            return cached
            
        result = await self.get_activity_limits()
        if result:
            await self.cache.set(cache_key, result, ttl=60)
        return result

    async def get_group_cached(self, chat_id: int) -> Optional[Dict]:
        """带缓存的获取群组配置"""
        cache_key = f"group:{chat_id}"
        cached = await self.cache.get(cache_key)
        if cached is not None:
            return cached
            
        result = await self.get_group(chat_id)
        if result:
            await self.cache.set(cache_key, result, ttl=60)
        return result

    # ========== 群组相关操作 ==========
    async def get_group(self, chat_id: int) -> Optional[Dict]:
        """获取群组配置 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                row = await self.execute_query(
                    conn,
                    "SELECT * FROM groups WHERE chat_id = $1",
                    (chat_id,),
                    fetchone=True,
                )
            else:
                row = await self.execute_query(
                    conn,
                    "SELECT * FROM groups WHERE chat_id = ?",
                    (chat_id,),
                    fetchone=True,
                )
            return row
        finally:
            await self.release_connection(conn)

    async def init_group(self, chat_id: int):
        """初始化群组 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    "INSERT INTO groups (chat_id) VALUES ($1) ON CONFLICT (chat_id) DO NOTHING",
                    (chat_id,),
                )
            else:
                await self.execute_query(
                    conn,
                    "INSERT OR IGNORE INTO groups (chat_id) VALUES (?)",
                    (chat_id,),
                )
            await conn.commit()
            
            # 清除相关缓存
            await self.cache.delete(f"group:{chat_id}") 
        finally:
            await self.release_connection(conn)

    async def update_group_channel(self, chat_id: int, channel_id: int):
        """更新群组频道ID - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    "UPDATE groups SET channel_id = $1, updated_at = CURRENT_TIMESTAMP WHERE chat_id = $2",
                    (channel_id, chat_id),
                )
            else:
                await self.execute_query(
                    conn,
                    "UPDATE groups SET channel_id = ?, updated_at = CURRENT_TIMESTAMP WHERE chat_id = ?",
                    (channel_id, chat_id),
                )
            await conn.commit()
            await self.cache.delete(f"group:{chat_id}")
        finally:
            await self.release_connection(conn)

    async def update_group_notification(self, chat_id: int, group_id: int):
        """更新群组通知群组ID - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    "UPDATE groups SET notification_group_id = $1, updated_at = CURRENT_TIMESTAMP WHERE chat_id = $2",
                    (group_id, chat_id),
                )
            else:
                await self.execute_query(
                    conn,
                    "UPDATE groups SET notification_group_id = ?, updated_at = CURRENT_TIMESTAMP WHERE chat_id = ?",
                    (group_id, chat_id),
                )
            await conn.commit()
            await self.cache.delete(f"group:{chat_id}")
        finally:
            await self.release_connection(conn)

    async def update_group_reset_time(self, chat_id: int, hour: int, minute: int):
        """更新群组重置时间 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    "UPDATE groups SET reset_hour = $1, reset_minute = $2, updated_at = CURRENT_TIMESTAMP WHERE chat_id = $3",
                    (hour, minute, chat_id),
                )
            else:
                await self.execute_query(
                    conn,
                    "UPDATE groups SET reset_hour = ?, reset_minute = ?, updated_at = CURRENT_TIMESTAMP WHERE chat_id = ?",
                    (hour, minute, chat_id),
                )
            await conn.commit()
            await self.cache.delete(f"group:{chat_id}")
        finally:
            await self.release_connection(conn)

    async def update_group_work_time(
        self, chat_id: int, work_start: str, work_end: str
    ):
        """更新群组上下班时间 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    "UPDATE groups SET work_start_time = $1, work_end_time = $2, updated_at = CURRENT_TIMESTAMP WHERE chat_id = $3",
                    (work_start, work_end, chat_id),
                )
            else:
                await self.execute_query(
                    conn,
                    "UPDATE groups SET work_start_time = ?, work_end_time = ?, updated_at = CURRENT_TIMESTAMP WHERE chat_id = ?",
                    (work_start, work_end, chat_id),
                )
            await conn.commit()
            await self.cache.delete(f"group:{chat_id}")
        finally:
            await self.release_connection(conn)

    async def get_group_work_time(self, chat_id: int) -> Dict[str, str]:
        """获取群组上下班时间 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                row = await self.execute_query(
                    conn,
                    "SELECT work_start_time, work_end_time FROM groups WHERE chat_id = $1",
                    (chat_id,),
                    fetchone=True,
                )
            else:
                row = await self.execute_query(
                    conn,
                    "SELECT work_start_time, work_end_time FROM groups WHERE chat_id = ?",
                    (chat_id,),
                    fetchone=True,
                )
            if row and row["work_start_time"] and row["work_end_time"]:
                return {
                    "work_start": row["work_start_time"],
                    "work_end": row["work_end_time"],
                }
            return Config.DEFAULT_WORK_HOURS.copy()
        finally:
            await self.release_connection(conn)

    async def has_work_hours_enabled(self, chat_id: int) -> bool:
        """检查是否启用了上下班功能 - 优化版本"""
        work_hours = await self.get_group_work_time(chat_id)
        return (
            work_hours["work_start"] != Config.DEFAULT_WORK_HOURS["work_start"]
            and work_hours["work_end"] != Config.DEFAULT_WORK_HOURS["work_end"]
        )

    # ========== 用户相关操作 ==========
    async def get_user(self, chat_id: int, user_id: int) -> Optional[Dict]:
        """获取用户数据 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                row = await self.execute_query(
                    conn,
                    "SELECT * FROM users WHERE chat_id = $1 AND user_id = $2",
                    (chat_id, user_id),
                    fetchone=True,
                )
            else:
                row = await self.execute_query(
                    conn,
                    "SELECT * FROM users WHERE chat_id = ? AND user_id = ?",
                    (chat_id, user_id),
                    fetchone=True,
                )
            return row
        finally:
            await self.release_connection(conn)

    async def init_user(self, chat_id: int, user_id: int, nickname: str = None):
        """初始化用户 - 优化版本"""
        today = str(datetime.now().date())
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    "INSERT INTO users (chat_id, user_id, nickname, last_updated) VALUES ($1, $2, $3, $4) ON CONFLICT (chat_id, user_id) DO NOTHING",
                    (chat_id, user_id, nickname, today),
                )
            else:
                await self.execute_query(
                    conn,
                    "INSERT OR IGNORE INTO users (chat_id, user_id, nickname, last_updated) VALUES (?, ?, ?, ?)",
                    (chat_id, user_id, nickname, today),
                )
            await conn.commit()
            await self.cache.delete(f"user:{chat_id}:{user_id}")
        finally:
            await self.release_connection(conn)

    @track_performance("update_user_activity")
    async def update_user_activity(
        self,
        chat_id: int,
        user_id: int,
        activity: str = None,
        start_time: str = None,
        nickname: str = None,
    ):
        """更新用户活动状态 - 优化版本"""
        conn = await self.get_connection()
        try:
            update_fields = []
            params = []

            if activity is not None:
                update_fields.append(
                    "current_activity = $1"
                    if self.db_type == "postgresql"
                    else "current_activity = ?"
                )
                params.append(activity)

            if start_time is not None:
                update_fields.append(
                    "activity_start_time = $1"
                    if self.db_type == "postgresql"
                    else "activity_start_time = ?"
                )
                params.append(start_time)

            if nickname is not None:
                update_fields.append(
                    "nickname = $1" if self.db_type == "postgresql" else "nickname = ?"
                )
                params.append(nickname)

            update_fields.append("updated_at = CURRENT_TIMESTAMP")
            params.extend([chat_id, user_id])

            if self.db_type == "postgresql":
                query = f"UPDATE users SET {', '.join(update_fields)} WHERE chat_id = ${len(params)-1} AND user_id = ${len(params)}"
            else:
                query = f"UPDATE users SET {', '.join(update_fields)} WHERE chat_id = ? AND user_id = ?"

            await self.execute_query(conn, query, tuple(params))
            await conn.commit()
            await self.cache.delete(f"user:{chat_id}:{user_id}") 
        finally:
            await self.release_connection(conn)

    @track_performance("complete_user_activity")
    @with_retry("complete_user_activity", max_retries=3)
    async def complete_user_activity(
        self,
        chat_id: int,
        user_id: int,
        activity: str,
        elapsed_time: int,
        fine_amount: int = 0,
        is_overtime: bool = False,
    ):
        """完成用户活动 - 优化版本"""
        today = str(datetime.now().date())
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                # 更新用户活动记录
                await self.execute_query(
                    conn,
                    """
                    INSERT INTO user_activities 
                    (chat_id, user_id, activity_date, activity_name, activity_count, accumulated_time)
                    VALUES ($1, $2, $3, $4, 
                    COALESCE((SELECT activity_count FROM user_activities 
                             WHERE chat_id = $1 AND user_id = $2 AND activity_date = $3 AND activity_name = $4), 0) + 1,
                    COALESCE((SELECT accumulated_time FROM user_activities 
                             WHERE chat_id = $1 AND user_id = $2 AND activity_date = $3 AND activity_name = $4), 0) + $5)
                    ON CONFLICT (chat_id, user_id, activity_date, activity_name) 
                    DO UPDATE SET 
                        activity_count = EXCLUDED.activity_count,
                        accumulated_time = EXCLUDED.accumulated_time,
                        updated_at = CURRENT_TIMESTAMP
                    """,
                    (chat_id, user_id, today, activity, elapsed_time),
                )
            else:
                # 更新用户活动记录 - SQLite
                await self.execute_query(
                    conn,
                    """
                    INSERT OR REPLACE INTO user_activities 
                    (chat_id, user_id, activity_date, activity_name, activity_count, accumulated_time)
                    VALUES (?, ?, ?, ?, 
                    COALESCE((SELECT activity_count FROM user_activities 
                             WHERE chat_id = ? AND user_id = ? AND activity_date = ? AND activity_name = ?), 0) + 1,
                    COALESCE((SELECT accumulated_time FROM user_activities 
                             WHERE chat_id = ? AND user_id = ? AND activity_date = ? AND activity_name = ?), 0) + ?)
                    """,
                    (
                        chat_id,
                        user_id,
                        today,
                        activity,
                        chat_id,
                        user_id,
                        today,
                        activity,
                        chat_id,
                        user_id,
                        today,
                        activity,
                        elapsed_time,
                    ),
                )

            # 更新用户总数据
            update_fields = []
            params = []

            update_fields.append(
                "total_accumulated_time = total_accumulated_time + $1"
                if self.db_type == "postgresql"
                else "total_accumulated_time = total_accumulated_time + ?"
            )
            params.append(elapsed_time)

            update_fields.append("total_activity_count = total_activity_count + 1")

            if fine_amount > 0:
                update_fields.append(
                    "total_fines = total_fines + $1"
                    if self.db_type == "postgresql"
                    else "total_fines = total_fines + ?"
                )
                params.append(fine_amount)

            if is_overtime:
                update_fields.append("overtime_count = overtime_count + 1")
                time_limit = await self.get_activity_time_limit(activity)
                overtime_seconds = max(0, elapsed_time - (time_limit * 60))
                update_fields.append(
                    "total_overtime_time = total_overtime_time + $1"
                    if self.db_type == "postgresql"
                    else "total_overtime_time = total_overtime_time + ?"
                )
                params.append(overtime_seconds)

            update_fields.append(
                "last_updated = $1"
                if self.db_type == "postgresql"
                else "last_updated = ?"
            )
            params.append(today)

            update_fields.append("current_activity = NULL")
            update_fields.append("activity_start_time = NULL")

            params.extend([chat_id, user_id])

            if self.db_type == "postgresql":
                query = f"UPDATE users SET {', '.join(update_fields)} WHERE chat_id = ${len(params)-1} AND user_id = ${len(params)}"
            else:
                query = f"UPDATE users SET {', '.join(update_fields)} WHERE chat_id = ? AND user_id = ?"

            await self.execute_query(conn, query, tuple(params))
            await conn.commit()
            await self.cache.delete(f"user:{chat_id}:{user_id}") 
        finally:
            await self.release_connection(conn)

    async def reset_user_daily_data(self, chat_id: int, user_id: int):
        """重置用户每日数据 - 优化版本"""
        today = str(datetime.now().date())
        conn = await self.get_connection()
        try:
            # 删除今日活动记录
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    "DELETE FROM user_activities WHERE chat_id = $1 AND user_id = $2 AND activity_date = $3",
                    (chat_id, user_id, today),
                )
            else:
                await self.execute_query(
                    conn,
                    "DELETE FROM user_activities WHERE chat_id = ? AND user_id = ? AND activity_date = ?",
                    (chat_id, user_id, today),
                )

            # 重置用户数据
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    "UPDATE users SET total_accumulated_time = 0, total_activity_count = 0, total_fines = 0, overtime_count = 0, total_overtime_time = 0, last_updated = $1 WHERE chat_id = $2 AND user_id = $3",
                    (today, chat_id, user_id),
                )
            else:
                await self.execute_query(
                    conn,
                    "UPDATE users SET total_accumulated_time = 0, total_activity_count = 0, total_fines = 0, overtime_count = 0, total_overtime_time = 0, last_updated = ? WHERE chat_id = ? AND user_id = ?",
                    (today, chat_id, user_id),
                )
            await conn.commit()
            await self.cache.delete(f"user:{chat_id}:{user_id}")
        finally:
            await self.release_connection(conn)

    async def get_user_activity_count(
        self, chat_id: int, user_id: int, activity: str
    ) -> int:
        """获取用户今日活动次数 - 优化版本"""
        today = str(datetime.now().date())
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                row = await self.execute_query(
                    conn,
                    "SELECT activity_count FROM user_activities WHERE chat_id = $1 AND user_id = $2 AND activity_date = $3 AND activity_name = $4",
                    (chat_id, user_id, today, activity),
                    fetchone=True,
                )
            else:
                row = await self.execute_query(
                    conn,
                    "SELECT activity_count FROM user_activities WHERE chat_id = ? AND user_id = ? AND activity_date = ? AND activity_name = ?",
                    (chat_id, user_id, today, activity),
                    fetchone=True,
                )
            return row["activity_count"] if row else 0
        finally:
            await self.release_connection(conn)

    async def get_user_activity_time(
        self, chat_id: int, user_id: int, activity: str
    ) -> int:
        """获取用户今日活动累计时间 - 优化版本"""
        today = str(datetime.now().date())
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                row = await self.execute_query(
                    conn,
                    "SELECT accumulated_time FROM user_activities WHERE chat_id = $1 AND user_id = $2 AND activity_date = $3 AND activity_name = $4",
                    (chat_id, user_id, today, activity),
                    fetchone=True,
                )
            else:
                row = await self.execute_query(
                    conn,
                    "SELECT accumulated_time FROM user_activities WHERE chat_id = ? AND user_id = ? AND activity_date = ? AND activity_name = ?",
                    (chat_id, user_id, today, activity),
                    fetchone=True,
                )
            return row["accumulated_time"] if row else 0
        finally:
            await self.release_connection(conn)

    async def get_user_all_activities(
        self, chat_id: int, user_id: int
    ) -> Dict[str, Dict]:
        """获取用户所有活动数据 - 优化版本"""
        today = str(datetime.now().date())
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                rows = await self.execute_query(
                    conn,
                    "SELECT activity_name, activity_count, accumulated_time FROM user_activities WHERE chat_id = $1 AND user_id = $2 AND activity_date = $3",
                    (chat_id, user_id, today),
                    fetchall=True,
                )
            else:
                rows = await self.execute_query(
                    conn,
                    "SELECT activity_name, activity_count, accumulated_time FROM user_activities WHERE chat_id = ? AND user_id = ? AND activity_date = ?",
                    (chat_id, user_id, today),
                    fetchall=True,
                )

            activities = {}
            for row in rows:
                activities[row["activity_name"]] = {
                    "count": row["activity_count"],
                    "time": row["accumulated_time"],
                    "time_formatted": self.format_seconds_to_hms(
                        row["accumulated_time"]
                    ),
                }
            return activities
        finally:
            await self.release_connection(conn)

    # ========== 上下班记录操作 ==========
    @track_performance("add_work_record")
    async def add_work_record(
        self,
        chat_id: int,
        user_id: int,
        record_date: str,
        checkin_type: str,
        checkin_time: str,
        status: str,
        time_diff_minutes: float,
        fine_amount: int = 0,
    ):
        """添加上下班记录 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    """
                    INSERT INTO work_records 
                    (chat_id, user_id, record_date, checkin_type, checkin_time, status, time_diff_minutes, fine_amount)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
                    ON CONFLICT (chat_id, user_id, record_date, checkin_type) 
                    DO UPDATE SET 
                        checkin_time = EXCLUDED.checkin_time,
                        status = EXCLUDED.status,
                        time_diff_minutes = EXCLUDED.time_diff_minutes,
                        fine_amount = EXCLUDED.fine_amount,
                        created_at = CURRENT_TIMESTAMP
                    """,
                    (
                        chat_id,
                        user_id,
                        record_date,
                        checkin_type,
                        checkin_time,
                        status,
                        time_diff_minutes,
                        fine_amount,
                    ),
                )
            else:
                await self.execute_query(
                    conn,
                    """
                    INSERT OR REPLACE INTO work_records 
                    (chat_id, user_id, record_date, checkin_type, checkin_time, status, time_diff_minutes, fine_amount)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        chat_id,
                        user_id,
                        record_date,
                        checkin_type,
                        checkin_time,
                        status,
                        time_diff_minutes,
                        fine_amount,
                    ),
                )

            if fine_amount > 0:
                if self.db_type == "postgresql":
                    await self.execute_query(
                        conn,
                        "UPDATE users SET total_fines = total_fines + $1 WHERE chat_id = $2 AND user_id = $3",
                        (fine_amount, chat_id, user_id),
                    )
                else:
                    await self.execute_query(
                        conn,
                        "UPDATE users SET total_fines = total_fines + ? WHERE chat_id = ? AND user_id = ?",
                        (fine_amount, chat_id, user_id),
                    )

            await conn.commit()
            await self.cache.delete(f"user:{chat_id}:{user_id}") 
        finally:
            await self.release_connection(conn)

    async def get_user_work_records(
        self, chat_id: int, user_id: int, limit: int = 7
    ) -> List[Dict]:
        """获取用户上下班记录 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                rows = await self.execute_query(
                    conn,
                    "SELECT * FROM work_records WHERE chat_id = $1 AND user_id = $2 ORDER BY record_date DESC, checkin_type LIMIT $3",
                    (chat_id, user_id, limit * 2),
                    fetchall=True,
                )
            else:
                rows = await self.execute_query(
                    conn,
                    "SELECT * FROM work_records WHERE chat_id = ? AND user_id = ? ORDER BY record_date DESC, checkin_type LIMIT ?",
                    (chat_id, user_id, limit * 2),
                    fetchall=True,
                )

            result = []
            for row in rows:
                record = dict(row)
                if record["time_diff_minutes"]:
                    record["time_diff_formatted"] = self.format_minutes_to_hm(
                        record["time_diff_minutes"]
                    )
                else:
                    record["time_diff_formatted"] = "0小时0分钟"
                result.append(record)

            return result
        finally:
            await self.release_connection(conn)

    async def has_work_record_today(
        self, chat_id: int, user_id: int, checkin_type: str
    ) -> bool:
        """检查今天是否有指定类型的上下班记录 - 优化版本"""
        today = str(datetime.now().date())
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                row = await self.execute_query(
                    conn,
                    "SELECT 1 FROM work_records WHERE chat_id = $1 AND user_id = $2 AND record_date = $3 AND checkin_type = $4",
                    (chat_id, user_id, today, checkin_type),
                    fetchone=True,
                )
            else:
                row = await self.execute_query(
                    conn,
                    "SELECT 1 FROM work_records WHERE chat_id = ? AND user_id = ? AND record_date = ? AND checkin_type = ?",
                    (chat_id, user_id, today, checkin_type),
                    fetchone=True,
                )
            return row is not None
        finally:
            await self.release_connection(conn)

    async def get_today_work_records(
        self, chat_id: int, user_id: int
    ) -> Dict[str, Dict]:
        """获取用户今天的上下班记录 - 优化版本"""
        today = str(datetime.now().date())
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                rows = await self.execute_query(
                    conn,
                    "SELECT * FROM work_records WHERE chat_id = $1 AND user_id = $2 AND record_date = $3",
                    (chat_id, user_id, today),
                    fetchall=True,
                )
            else:
                rows = await self.execute_query(
                    conn,
                    "SELECT * FROM work_records WHERE chat_id = ? AND user_id = ? AND record_date = ?",
                    (chat_id, user_id, today),
                    fetchall=True,
                )

            records = {}
            for row in rows:
                record = dict(row)
                if record["time_diff_minutes"]:
                    record["time_diff_formatted"] = self.format_minutes_to_hm(
                        record["time_diff_minutes"]
                    )
                else:
                    record["time_diff_formatted"] = "0小时0分钟"
                records[row["checkin_type"]] = record
            return records
        finally:
            await self.release_connection(conn)

    # ========== 活动配置操作 ==========
    async def get_activity_limits(self) -> Dict:
        """获取所有活动限制 - 优化版本"""
        conn = await self.get_connection()
        try:
            rows = await self.execute_query(
                conn, "SELECT * FROM activity_configs", fetchall=True
            )
            return {
                row["activity_name"]: {
                    "max_times": row["max_times"],
                    "time_limit": row["time_limit"],
                }
                for row in rows
            }
        finally:
            await self.release_connection(conn)

    async def get_activity_time_limit(self, activity: str) -> int:
        """获取活动时间限制 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                row = await self.execute_query(
                    conn,
                    "SELECT time_limit FROM activity_configs WHERE activity_name = $1",
                    (activity,),
                    fetchone=True,
                )
            else:
                row = await self.execute_query(
                    conn,
                    "SELECT time_limit FROM activity_configs WHERE activity_name = ?",
                    (activity,),
                    fetchone=True,
                )
            return row["time_limit"] if row else 0
        finally:
            await self.release_connection(conn)

    async def get_activity_max_times(self, activity: str) -> int:
        """获取活动最大次数 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                row = await self.execute_query(
                    conn,
                    "SELECT max_times FROM activity_configs WHERE activity_name = $1",
                    (activity,),
                    fetchone=True,
                )
            else:
                row = await self.execute_query(
                    conn,
                    "SELECT max_times FROM activity_configs WHERE activity_name = ?",
                    (activity,),
                    fetchone=True,
                )
            return row["max_times"] if row else 0
        finally:
            await self.release_connection(conn)

    async def update_activity_config(
        self, activity: str, max_times: int, time_limit: int
    ):
        """更新活动配置 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    """
                    INSERT INTO activity_configs (activity_name, max_times, time_limit)
                    VALUES ($1, $2, $3)
                    ON CONFLICT (activity_name) 
                    DO UPDATE SET 
                        max_times = EXCLUDED.max_times,
                        time_limit = EXCLUDED.time_limit,
                        created_at = CURRENT_TIMESTAMP
                    """,
                    (activity, max_times, time_limit),
                )
            else:
                await self.execute_query(
                    conn,
                    """
                    INSERT OR REPLACE INTO activity_configs (activity_name, max_times, time_limit)
                    VALUES (?, ?, ?)
                    """,
                    (activity, max_times, time_limit),
                )
            await conn.commit()
            await self.cache.delete("activity_limits")
        finally:
            await self.release_connection(conn)

    async def delete_activity_config(self, activity: str):
        """删除活动配置 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    "DELETE FROM activity_configs WHERE activity_name = $1",
                    (activity,),
                )
                await self.execute_query(
                    conn,
                    "DELETE FROM fine_configs WHERE activity_name = $1",
                    (activity,),
                )
            else:
                await self.execute_query(
                    conn,
                    "DELETE FROM activity_configs WHERE activity_name = ?",
                    (activity,),
                )
                await self.execute_query(
                    conn,
                    "DELETE FROM fine_configs WHERE activity_name = ?",
                    (activity,),
                )
            await conn.commit()
            await self.cache.delete("activity_limits")
        finally:
            await self.release_connection(conn)

    async def activity_exists(self, activity: str) -> bool:
        """检查活动是否存在 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                row = await self.execute_query(
                    conn,
                    "SELECT 1 FROM activity_configs WHERE activity_name = $1",
                    (activity,),
                    fetchone=True,
                )
            else:
                row = await self.execute_query(
                    conn,
                    "SELECT 1 FROM activity_configs WHERE activity_name = ?",
                    (activity,),
                    fetchone=True,
                )
            return row is not None
        finally:
            await self.release_connection(conn)

    # ========== 罚款配置操作 ==========
    async def get_fine_rates(self) -> Dict:
        """获取所有罚款费率 - 优化版本"""
        conn = await self.get_connection()
        try:
            rows = await self.execute_query(
                conn, "SELECT * FROM fine_configs", fetchall=True
            )
            fines = {}
            for row in rows:
                activity = row["activity_name"]
                if activity not in fines:
                    fines[activity] = {}
                fines[activity][row["time_segment"]] = row["fine_amount"]
            return fines
        finally:
            await self.release_connection(conn)

    async def get_fine_rates_for_activity(self, activity: str) -> Dict:
        """获取指定活动的罚款费率 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                rows = await self.execute_query(
                    conn,
                    "SELECT time_segment, fine_amount FROM fine_configs WHERE activity_name = $1",
                    (activity,),
                    fetchall=True,
                )
            else:
                rows = await self.execute_query(
                    conn,
                    "SELECT time_segment, fine_amount FROM fine_configs WHERE activity_name = ?",
                    (activity,),
                    fetchall=True,
                )
            return {row["time_segment"]: row["fine_amount"] for row in rows}
        finally:
            await self.release_connection(conn)

    async def update_fine_config(
        self, activity: str, time_segment: str, fine_amount: int
    ):
        """更新罚款配置 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    """
                    INSERT INTO fine_configs (activity_name, time_segment, fine_amount)
                    VALUES ($1, $2, $3)
                    ON CONFLICT (activity_name, time_segment) 
                    DO UPDATE SET 
                        fine_amount = EXCLUDED.fine_amount,
                        created_at = CURRENT_TIMESTAMP
                    """,
                    (activity, time_segment, fine_amount),
                )
            else:
                await self.execute_query(
                    conn,
                    """
                    INSERT OR REPLACE INTO fine_configs (activity_name, time_segment, fine_amount)
                    VALUES (?, ?, ?)
                    """,
                    (activity, time_segment, fine_amount),
                )
            await conn.commit()
        finally:
            await self.release_connection(conn)

    async def get_work_fine_rates(self) -> Dict:
        """获取上下班罚款费率 - 优化版本"""
        conn = await self.get_connection()
        try:
            rows = await self.execute_query(
                conn, "SELECT * FROM work_fine_configs", fetchall=True
            )
            fines = {}
            for row in rows:
                checkin_type = row["checkin_type"]
                if checkin_type not in fines:
                    fines[checkin_type] = {}
                fines[checkin_type][row["time_segment"]] = row["fine_amount"]
            return fines
        finally:
            await self.release_connection(conn)

    async def get_work_fine_rates_for_type(self, checkin_type: str) -> Dict:
        """获取指定类型的上下班罚款费率 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                rows = await self.execute_query(
                    conn,
                    "SELECT time_segment, fine_amount FROM work_fine_configs WHERE checkin_type = $1",
                    (checkin_type,),
                    fetchall=True,
                )
            else:
                rows = await self.execute_query(
                    conn,
                    "SELECT time_segment, fine_amount FROM work_fine_configs WHERE checkin_type = ?",
                    (checkin_type,),
                    fetchall=True,
                )
            return {row["time_segment"]: row["fine_amount"] for row in rows}
        finally:
            await self.release_connection(conn)

    async def update_work_fine_config(
        self, checkin_type: str, time_segment: str, fine_amount: int
    ):
        """更新上下班罚款配置 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    """
                    INSERT INTO work_fine_configs (checkin_type, time_segment, fine_amount)
                    VALUES ($1, $2, $3)
                    ON CONFLICT (checkin_type, time_segment) 
                    DO UPDATE SET 
                        fine_amount = EXCLUDED.fine_amount,
                        created_at = CURRENT_TIMESTAMP
                    """,
                    (checkin_type, time_segment, fine_amount),
                )
            else:
                await self.execute_query(
                    conn,
                    """
                    INSERT OR REPLACE INTO work_fine_configs (checkin_type, time_segment, fine_amount)
                    VALUES (?, ?, ?)
                    """,
                    (checkin_type, time_segment, fine_amount),
                )
            await conn.commit()
        finally:
            await self.release_connection(conn)

    # ========== 推送设置操作 ==========
    async def get_push_settings(self) -> Dict:
        """获取推送设置 - 优化版本"""
        conn = await self.get_connection()
        try:
            rows = await self.execute_query(
                conn, "SELECT * FROM push_settings", fetchall=True
            )
            return {row["setting_key"]: bool(row["setting_value"]) for row in rows}
        finally:
            await self.release_connection(conn)

    async def update_push_setting(self, key: str, value: bool):
        """更新推送设置 - 优化版本"""
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    """
                    INSERT INTO push_settings (setting_key, setting_value)
                    VALUES ($1, $2)
                    ON CONFLICT (setting_key) 
                    DO UPDATE SET 
                        setting_value = EXCLUDED.setting_value,
                        created_at = CURRENT_TIMESTAMP
                    """,
                    (key, 1 if value else 0),
                )
            else:
                await self.execute_query(
                    conn,
                    """
                    INSERT OR REPLACE INTO push_settings (setting_key, setting_value)
                    VALUES (?, ?)
                    """,
                    (key, 1 if value else 0),
                )
            await conn.commit()
        finally:
            await self.release_connection(conn)

    # ========== 统计和导出相关 ==========
    async def get_group_statistics(self, chat_id: int) -> List[Dict]:
        """获取群组统计信息 - 优化版本"""
        today = str(datetime.now().date())
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                users = await self.execute_query(
                    conn,
                    "SELECT user_id, nickname, total_accumulated_time, total_activity_count, total_fines, overtime_count, total_overtime_time FROM users WHERE chat_id = $1 AND last_updated = $2",
                    (chat_id, today),
                    fetchall=True,
                )
            else:
                users = await self.execute_query(
                    conn,
                    "SELECT user_id, nickname, total_accumulated_time, total_activity_count, total_fines, overtime_count, total_overtime_time FROM users WHERE chat_id = ? AND last_updated = ?",
                    (chat_id, today),
                    fetchall=True,
                )

            result = []
            for user in users:
                user_data = dict(user)
                user_data["total_accumulated_time_formatted"] = (
                    self.format_seconds_to_hms(user_data["total_accumulated_time"])
                )
                user_data["total_overtime_time_formatted"] = self.format_seconds_to_hms(
                    user_data["total_overtime_time"]
                )

                # 获取用户的活动详情
                if self.db_type == "postgresql":
                    activities = await self.execute_query(
                        conn,
                        "SELECT activity_name, activity_count, accumulated_time FROM user_activities WHERE chat_id = $1 AND user_id = $2 AND activity_date = $3",
                        (chat_id, user["user_id"], today),
                        fetchall=True,
                    )
                else:
                    activities = await self.execute_query(
                        conn,
                        "SELECT activity_name, activity_count, accumulated_time FROM user_activities WHERE chat_id = ? AND user_id = ? AND activity_date = ?",
                        (chat_id, user["user_id"], today),
                        fetchall=True,
                    )

                user_data["activities"] = {}
                for row in activities:
                    user_data["activities"][row["activity_name"]] = {
                        "count": row["activity_count"],
                        "time": row["accumulated_time"],
                        "time_formatted": self.format_seconds_to_hms(
                            row["accumulated_time"]
                        ),
                    }

                result.append(user_data)

            return result
        finally:
            await self.release_connection(conn)

    async def get_all_groups(self) -> List[int]:
        """获取所有群组ID - 优化版本"""
        conn = await self.get_connection()
        try:
            rows = await self.execute_query(
                conn, "SELECT chat_id FROM groups", fetchall=True
            )
            return [row["chat_id"] for row in rows]
        finally:
            await self.release_connection(conn)

    async def get_group_members(self, chat_id: int) -> List[Dict]:
        """获取群组成员 - 优化版本"""
        today = str(datetime.now().date())
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                rows = await self.execute_query(
                    conn,
                    "SELECT user_id, nickname, current_activity, activity_start_time, total_accumulated_time, total_activity_count, total_fines, overtime_count, total_overtime_time FROM users WHERE chat_id = $1 AND last_updated = $2",
                    (chat_id, today),
                    fetchall=True,
                )
            else:
                rows = await self.execute_query(
                    conn,
                    "SELECT user_id, nickname, current_activity, activity_start_time, total_accumulated_time, total_activity_count, total_fines, overtime_count, total_overtime_time FROM users WHERE chat_id = ? AND last_updated = ?",
                    (chat_id, today),
                    fetchall=True,
                )

            result = []
            for row in rows:
                user_data = dict(row)
                user_data["total_accumulated_time_formatted"] = (
                    self.format_seconds_to_hms(user_data["total_accumulated_time"])
                )
                user_data["total_overtime_time_formatted"] = self.format_seconds_to_hms(
                    user_data["total_overtime_time"]
                )
                result.append(user_data)

            return result
        finally:
            await self.release_connection(conn)

    # ========== 数据清理 ==========
    async def cleanup_old_data(self, days: int = 30):
        """清理旧数据 - 优化版本"""
        cutoff_date = (datetime.now() - timedelta(days=days)).date()
        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                await self.execute_query(
                    conn,
                    "DELETE FROM user_activities WHERE activity_date < $1",
                    (str(cutoff_date),),
                )
                await self.execute_query(
                    conn,
                    "DELETE FROM work_records WHERE record_date < $1",
                    (str(cutoff_date),),
                )
                await self.execute_query(
                    conn,
                    "DELETE FROM users WHERE last_updated < $1",
                    (str(cutoff_date),),
                )
            else:
                await self.execute_query(
                    conn,
                    "DELETE FROM user_activities WHERE activity_date < ?",
                    (str(cutoff_date),),
                )
                await self.execute_query(
                    conn,
                    "DELETE FROM work_records WHERE record_date < ?",
                    (str(cutoff_date),),
                )
                await self.execute_query(
                    conn,
                    "DELETE FROM users WHERE last_updated < ?",
                    (str(cutoff_date),),
                )
            await conn.commit()
            # 清理缓存
            self._cache.clear()
            self._cache_ttl.clear()
        finally:
            await self.release_connection(conn)

    async def get_database_size(self) -> int:
        """获取数据库大小 - 优化版本"""
        if self.db_type == "postgresql":
            conn = await self.get_connection()
            try:
                # 提取数据库名
                db_name = self.database_url.split("/")[-1]
                row = await self.execute_query(
                    conn, "SELECT pg_database_size($1)", (db_name,), fetchone=True
                )
                return row[0] if row else 0
            finally:
                await self.release_connection(conn)
        else:
            import os
            if os.path.exists(self.db_path):
                return os.path.getsize(self.db_path)
            return 0

    # ========== 月度统计 ==========
    async def get_monthly_statistics(
        self, chat_id: int, year: int = None, month: int = None
    ) -> List[Dict]:
        """获取月度统计信息 - 优化版本"""
        if year is None or month is None:
            today = datetime.now()
            year = today.year
            month = today.month

        start_date = f"{year:04d}-{month:02d}-01"
        if month == 12:
            end_date = f"{year+1:04d}-01-01"
        else:
            end_date = f"{year:04d}-{month+1:02d}-01"

        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                monthly_stats = await self.execute_query(
                    conn,
                    """
                    SELECT 
                        u.user_id,
                        u.nickname,
                        SUM(COALESCE(ua.accumulated_time, 0)) as total_time,
                        SUM(COALESCE(ua.activity_count, 0)) as total_count,
                        SUM(COALESCE(u.total_fines, 0)) as total_fines,
                        SUM(COALESCE(u.overtime_count, 0)) as total_overtime_count,
                        SUM(COALESCE(u.total_overtime_time, 0)) as total_overtime_time
                    FROM users u
                    LEFT JOIN user_activities ua ON u.chat_id = ua.chat_id AND u.user_id = ua.user_id
                        AND ua.activity_date >= $1 AND ua.activity_date < $2
                    WHERE u.chat_id = $3
                    GROUP BY u.user_id, u.nickname
                    ORDER BY total_time DESC
                    """,
                    (start_date, end_date, chat_id),
                    fetchall=True,
                )
            else:
                monthly_stats = await self.execute_query(
                    conn,
                    """
                    SELECT 
                        u.user_id,
                        u.nickname,
                        SUM(COALESCE(ua.accumulated_time, 0)) as total_time,
                        SUM(COALESCE(ua.activity_count, 0)) as total_count,
                        SUM(COALESCE(u.total_fines, 0)) as total_fines,
                        SUM(COALESCE(u.overtime_count, 0)) as total_overtime_count,
                        SUM(COALESCE(u.total_overtime_time, 0)) as total_overtime_time
                    FROM users u
                    LEFT JOIN user_activities ua ON u.chat_id = ua.chat_id AND u.user_id = ua.user_id
                        AND ua.activity_date >= ? AND ua.activity_date < ?
                    WHERE u.chat_id = ?
                    GROUP BY u.user_id, u.nickname
                    ORDER BY total_time DESC
                    """,
                    (start_date, end_date, chat_id),
                    fetchall=True,
                )

            result = []
            for stat in monthly_stats:
                user_data = dict(stat)
                user_data["total_time"] = user_data["total_time"] or 0
                user_data["total_overtime_time"] = user_data["total_overtime_time"] or 0
                user_data["total_time"] = self.format_seconds_to_hms(
                    user_data["total_time"]
                )
                user_data["total_overtime_time"] = self.format_seconds_to_hms(
                    user_data["total_overtime_time"]
                )

                # 获取用户每项活动的详细统计
                if self.db_type == "postgresql":
                    activity_details = await self.execute_query(
                        conn,
                        """
                        SELECT 
                            activity_name,
                            SUM(activity_count) as activity_count,
                            SUM(accumulated_time) as accumulated_time
                        FROM user_activities
                        WHERE chat_id = $1 AND user_id = $2 AND activity_date >= $3 AND activity_date < $4
                        GROUP BY activity_name
                        """,
                        (chat_id, user_data["user_id"], start_date, end_date),
                        fetchall=True,
                    )
                else:
                    activity_details = await self.execute_query(
                        conn,
                        """
                        SELECT 
                            activity_name,
                            SUM(activity_count) as activity_count,
                            SUM(accumulated_time) as accumulated_time
                        FROM user_activities
                        WHERE chat_id = ? AND user_id = ? AND activity_date >= ? AND activity_date < ?
                        GROUP BY activity_name
                        """,
                        (chat_id, user_data["user_id"], start_date, end_date),
                        fetchall=True,
                    )

                user_data["activities"] = {}
                for row in activity_details:
                    activity_time = row["accumulated_time"] or 0
                    user_data["activities"][row["activity_name"]] = {
                        "count": row["activity_count"] or 0,
                        "time": self.format_seconds_to_hms(activity_time),
                    }

                result.append(user_data)

            return result
        finally:
            await self.release_connection(conn)

    async def get_monthly_statistics_batch(
        self, chat_id: int, year: int, month: int, limit: int, offset: int
    ) -> List[Dict]:
        """分批获取月度统计信息 - 优化版本"""
        start_date = f"{year:04d}-{month:02d}-01"
        if month == 12:
            end_date = f"{year+1:04d}-01-01"
        else:
            end_date = f"{year:04d}-{month+1:02d}-01"

        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                rows = await self.execute_query(
                    conn,
                    """
                    SELECT 
                        u.user_id,
                        u.nickname,
                        ua.activity_name,
                        SUM(ua.activity_count) as total_count,
                        SUM(ua.accumulated_time) as total_time
                    FROM users u
                    JOIN user_activities ua ON u.chat_id = ua.chat_id AND u.user_id = ua.user_id
                    WHERE u.chat_id = $1 
                        AND ua.activity_date >= $2 
                        AND ua.activity_date < $3
                    GROUP BY u.user_id, u.nickname, ua.activity_name
                    ORDER BY u.user_id, ua.activity_name
                    LIMIT $4 OFFSET $5
                    """,
                    (chat_id, start_date, end_date, limit, offset),
                    fetchall=True,
                )
            else:
                rows = await self.execute_query(
                    conn,
                    """
                    SELECT 
                        u.user_id,
                        u.nickname,
                        ua.activity_name,
                        SUM(ua.activity_count) as total_count,
                        SUM(ua.accumulated_time) as total_time
                    FROM users u
                    JOIN user_activities ua ON u.chat_id = ua.chat_id AND u.user_id = ua.user_id
                    WHERE u.chat_id = ? 
                        AND ua.activity_date >= ? 
                        AND ua.activity_date < ?
                    GROUP BY u.user_id, u.nickname, ua.activity_name
                    ORDER BY u.user_id, ua.activity_name
                    LIMIT ? OFFSET ?
                    """,
                    (chat_id, start_date, end_date, limit, offset),
                    fetchall=True,
                )

            # 按用户分组数据
            user_stats = {}
            for row in rows:
                user_id = row["user_id"]
                if user_id not in user_stats:
                    user_stats[user_id] = {
                        "user_id": user_id,
                        "nickname": row["nickname"],
                        "activities": {},
                    }

                user_stats[user_id]["activities"][row["activity_name"]] = {
                    "count": row["total_count"] or 0,
                    "time": row["total_time"] or 0,
                    "time_formatted": self.format_seconds_to_hms(
                        row["total_time"] or 0
                    ),
                }

            return list(user_stats.values())
        finally:
            await self.release_connection(conn)

    async def get_monthly_work_statistics(
        self, chat_id: int, year: int = None, month: int = None
    ) -> List[Dict]:
        """获取月度上下班统计 - 优化版本"""
        if year is None or month is None:
            today = datetime.now()
            year = today.year
            month = today.month

        start_date = f"{year:04d}-{month:02d}-01"
        if month == 12:
            end_date = f"{year+1:04d}-01-01"
        else:
            end_date = f"{year:04d}-{month+1:02d}-01"

        conn = await self.get_connection()
        try:
            if self.db_type == "postgresql":
                rows = await self.execute_query(
                    conn,
                    """
                    SELECT 
                        wr.user_id,
                        u.nickname,
                        COUNT(CASE WHEN wr.checkin_type = 'work_start' THEN 1 END) as work_start_count,
                        COUNT(CASE WHEN wr.checkin_type = 'work_end' THEN 1 END) as work_end_count,
                        SUM(CASE WHEN wr.checkin_type = 'work_start' THEN wr.fine_amount ELSE 0 END) as work_start_fines,
                        SUM(CASE WHEN wr.checkin_type = 'work_end' THEN wr.fine_amount ELSE 0 END) as work_end_fines,
                        AVG(CASE WHEN wr.checkin_type = 'work_start' THEN wr.time_diff_minutes ELSE NULL END) as avg_work_start_late,
                        AVG(CASE WHEN wr.checkin_type = 'work_end' THEN wr.time_diff_minutes ELSE NULL END) as avg_work_end_early
                    FROM work_records wr
                    JOIN users u ON wr.chat_id = u.chat_id AND wr.user_id = u.user_id
                    WHERE wr.chat_id = $1 AND wr.record_date >= $2 AND wr.record_date < $3
                    GROUP BY wr.user_id, u.nickname
                    ORDER BY work_start_count DESC, work_end_count DESC
                    """,
                    (chat_id, start_date, end_date),
                    fetchall=True,
                )
            else:
                rows = await self.execute_query(
                    conn,
                    """
                    SELECT 
                        wr.user_id,
                        u.nickname,
                        COUNT(CASE WHEN wr.checkin_type = 'work_start' THEN 1 END) as work_start_count,
                        COUNT(CASE WHEN wr.checkin_type = 'work_end' THEN 1 END) as work_end_count,
                        SUM(CASE WHEN wr.checkin_type = 'work_start' THEN wr.fine_amount ELSE 0 END) as work_start_fines,
                        SUM(CASE WHEN wr.checkin_type = 'work_end' THEN wr.fine_amount ELSE 0 END) as work_end_fines,
                        AVG(CASE WHEN wr.checkin_type = 'work_start' THEN wr.time_diff_minutes ELSE NULL END) as avg_work_start_late,
                        AVG(CASE WHEN wr.checkin_type = 'work_end' THEN wr.time_diff_minutes ELSE NULL END) as avg_work_end_early
                    FROM work_records wr
                    JOIN users u ON wr.chat_id = u.chat_id AND wr.user_id = u.user_id
                    WHERE wr.chat_id = ? AND wr.record_date >= ? AND wr.record_date < ?
                    GROUP BY wr.user_id, u.nickname
                    ORDER BY work_start_count DESC, work_end_count DESC
                    """,
                    (chat_id, start_date, end_date),
                    fetchall=True,
                )

            result = []
            for row in rows:
                user_data = dict(row)
                user_data["avg_work_start_late"] = user_data["avg_work_start_late"] or 0
                user_data["avg_work_end_early"] = user_data["avg_work_end_early"] or 0
                user_data["avg_work_start_late_formatted"] = self.format_minutes_to_hm(
                    user_data["avg_work_start_late"]
                )
                user_data["avg_work_end_early_formatted"] = self.format_minutes_to_hm(
                    user_data["avg_work_end_early"]
                )
                result.append(user_data)

            return result
        finally:
            await self.release_connection(conn)

    async def get_monthly_activity_ranking(
        self, chat_id: int, year: int = None, month: int = None
    ) -> Dict[str, List]:
        """获取月度活动排行榜 - 优化版本"""
        if year is None or month is None:
            today = datetime.now()
            year = today.year
            month = today.month

        start_date = f"{year:04d}-{month:02d}-01"
        if month == 12:
            end_date = f"{year+1:04d}-01-01"
        else:
            end_date = f"{year:04d}-{month+1:02d}-01"

        conn = await self.get_connection()
        try:
            activity_limits = await self.get_activity_limits()
            rankings = {}

            for activity in activity_limits.keys():
                if self.db_type == "postgresql":
                    rows = await self.execute_query(
                        conn,
                        """
                        SELECT 
                            u.user_id,
                            u.nickname,
                            SUM(COALESCE(ua.accumulated_time, 0)) as total_time,
                            SUM(COALESCE(ua.activity_count, 0)) as total_count
                        FROM user_activities ua
                        JOIN users u ON ua.chat_id = u.chat_id AND ua.user_id = u.user_id
                        WHERE ua.chat_id = $1 AND ua.activity_name = $2 AND ua.activity_date >= $3 AND ua.activity_date < $4
                        GROUP BY u.user_id, u.nickname
                        ORDER BY total_time DESC
                        LIMIT 10
                        """,
                        (chat_id, activity, start_date, end_date),
                        fetchall=True,
                    )
                else:
                    rows = await self.execute_query(
                        conn,
                        """
                        SELECT 
                            u.user_id,
                            u.nickname,
                            SUM(COALESCE(ua.accumulated_time, 0)) as total_time,
                            SUM(COALESCE(ua.activity_count, 0)) as total_count
                        FROM user_activities ua
                        JOIN users u ON ua.chat_id = u.chat_id AND ua.user_id = u.user_id
                        WHERE ua.chat_id = ? AND ua.activity_name = ? AND ua.activity_date >= ? AND ua.activity_date < ?
                        GROUP BY u.user_id, u.nickname
                        ORDER BY total_time DESC
                        LIMIT 10
                        """,
                        (chat_id, activity, start_date, end_date),
                        fetchall=True,
                    )

                formatted_rows = []
                for row in rows:
                    user_data = dict(row)
                    user_data["total_time"] = user_data["total_time"] or 0
                    user_data["total_time_formatted"] = self.format_seconds_to_hms(
                        user_data["total_time"]
                    )
                    formatted_rows.append(user_data)

                rankings[activity] = formatted_rows

            return rankings
        finally:
            await self.release_connection(conn)

    async def manage_monthly_data(self):
        """月度数据管理 - 优化版本"""
        try:
            # 清理过期数据（保留35天）
            await self.cleanup_old_data(Config.DATA_RETENTION_DAYS)
            logger.info(f"✅ 已清理 {Config.DATA_RETENTION_DAYS} 天前的数据")
        except Exception as e:
            logger.error(f"❌ 月度数据管理失败: {e}")

    async def should_create_monthly_archive(self) -> bool:
        """检查是否应该创建月度归档 - 优化版本"""
        today = datetime.now()
        return today.day == 1

    async def cleanup_cache(self):
        """清理缓存"""
        # current_time = time.time()
        # expired_keys = [
        #     key for key, expiry in self._cache_ttl.items()
        #     if current_time >= expiry
        # ]
        # for key in expired_keys:
        #     if key in self._cache:
        #         del self._cache[key]
        #     if key in self._cache_ttl:
        #         del self._cache_ttl[key]
        
        # if expired_keys:
        #     logger.info(f"🧹 清理了 {len(expired_keys)} 个过期缓存")
        await self.cache.clear_expired()

# 全局优化数据库实例
db = OptimizedAsyncDatabase()