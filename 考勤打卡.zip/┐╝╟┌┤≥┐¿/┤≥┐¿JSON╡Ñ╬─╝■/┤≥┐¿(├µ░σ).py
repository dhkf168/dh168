import asyncio
import json
import os
from datetime import datetime, timedelta
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import (
    InlineKeyboardButton, 
    InlineKeyboardMarkup, 
    InputFile, 
    ReplyKeyboardMarkup, 
    KeyboardButton
)
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
import csv
import matplotlib.pyplot as plt

# ==================== 集中配置区域 ====================
class Config:
    # Bot 配置
    TOKEN = "8150090742:AAGBp_s3yIkyzElpCDcDjjUDPnn8quwOuqU"  # 替换为你的Bot Token
    
    # 文件配置
    DATA_FILE = "group_data.json"
    ACTIVITY_FILE = "activities.json"
    
    # 管理员配置
    ADMINS = [8356418002, 87654321]  # 替换成管理员 Telegram ID 列表
    
    # 默认活动配置
    DEFAULT_ACTIVITY_LIMITS = {
        "吃饭": {"max_times": 2, "time_limit": 30},
        "小厕": {"max_times": 5, "time_limit": 5},
        "大厕": {"max_times": 2, "time_limit": 15},
        "抽烟": {"max_times": 5, "time_limit": 10},
        "学习": {"max_times": 5, "time_limit": 60},
        "休息": {"max_times": 5, "time_limit": 10},
    }
    
    # 罚款配置（分段罚款：{时间段: 金额}）
    DEFAULT_FINE_RATES = {
        "吃饭": {"10": 100, "30": 300},    # 10分钟内100元，10-30分钟300元
        "小厕": {"5": 50, "10": 100},      # 5分钟内50元，5-10分钟100元
        "大厕": {"15": 80, "30": 200},     # 15分钟内80元，15-30分钟200元
        "抽烟": {"10": 200, "30": 500},    # 10分钟内200元，10-30分钟500元
        "学习": {"30": 50, "60": 100},     # 30分钟内50元，30-60分钟100元
        "休息": {"10": 50, "30": 100},     # 10分钟内50元，10-30分钟100元
    }
    
    # 超时配置
    AUTO_BACK_MINUTES = 30  # 现在只用于提醒，不强制回座
    REMINDER_INTERVAL = 5
    
    # 每日重置时间配置（24小时制）
    DAILY_RESET_HOUR = 0    # 0点重置
    DAILY_RESET_MINUTE = 0  # 0分
    
    # 消息模板
    MESSAGES = {
        "welcome": "欢迎使用群打卡机器人！请点击下方按钮打卡：",
        "no_activity": "❌ 没有找到正在进行的活动，请先打卡活动再回座。",
        "has_activity": "❌ 您当前有活动【{}】正在进行中，请先回座后才能开始新活动！",
        "no_permission": "❌ 你没有权限执行此操作",
        "no_data": "❌ 没有数据可生成图表",
        "max_times_reached": "❌ 您今日的{}次数已达到上限（{}次），无法再次打卡",
        "setchannel_usage": "❌ 用法：/setchannel <频道ID>\n频道ID格式如 -1001234567890",
        "setgroup_usage": "❌ 用法：/setgroup <群组ID>\n用于接收超时通知的群组ID",
        "set_usage": "❌ 用法：/set <用户ID> <活动> <时长分钟>",
        "reset_usage": "❌ 用法：/reset <用户ID>",
        "addactivity_usage": "❌ 用法：/addactivity <活动名> <max次数> <time_limit分钟>",
        "setresettime_usage": "❌ 用法：/setresettime <小时> <分钟>\n例如：/setresettime 0 0 表示每天0点重置",
        "setfine_usage": "❌ 用法：/setfine <活动名> <时间段> <金额>\n例如：/setfine 抽烟 10 200",
    }

# ==================== 状态机类 ====================
class AdminStates(StatesGroup):
    waiting_for_activity_name = State()
    waiting_for_max_times = State()
    waiting_for_time_limit = State()
    waiting_for_user_id = State()
    waiting_for_activity_type = State()
    waiting_for_minutes = State()
    waiting_for_channel_id = State()
    waiting_for_group_id = State()
    waiting_for_new_activity_name = State()
    waiting_for_new_max_times = State()
    waiting_for_new_time_limit = State()
    waiting_for_reset_hour = State()
    waiting_for_reset_minute = State()
    waiting_for_fine_activity = State()
    waiting_for_fine_time_segment = State()
    waiting_for_fine_amount = State()

# ==================== 初始化配置 ====================
config = Config()
storage = MemoryStorage()

# 内存数据
group_data = {}
activity_limits = config.DEFAULT_ACTIVITY_LIMITS.copy()
fine_rates = config.DEFAULT_FINE_RATES.copy()  # 罚款费率
tasks = {}  # 定时任务：chat_id-uid → asyncio.Task

bot = Bot(token=config.TOKEN)
dp = Dispatcher(storage=storage)

# ==================== 工具函数 ====================
def format_time(seconds: int):
    """格式化时间显示"""
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{h} 小时 {m} 分钟"
    elif m > 0:
        return f"{m} 分钟 {s} 秒"
    else:
        return f"{s} 秒"

def is_admin(uid):
    """检查用户是否为管理员"""
    return uid in config.ADMINS

def init_group(chat_id: int):
    """初始化群组数据"""
    if str(chat_id) not in group_data:
        group_data[str(chat_id)] = {
            "频道ID": None, 
            "通知群组ID": None,
            "每日重置时间": {"hour": config.DAILY_RESET_HOUR, "minute": config.DAILY_RESET_MINUTE},
            "成员": {}
        }

def init_user(chat_id: int, uid: int):
    """初始化用户数据"""
    init_group(chat_id)
    if str(uid) not in group_data[str(chat_id)]["成员"]:
        group_data[str(chat_id)]["成员"][str(uid)] = {
            "活动": None,
            "开始时间": None,
            "累计": {},
            "次数": {},
            "最后更新": str(datetime.now().date()),
            "昵称": None,
            "用户ID": uid,
            "总累计时间": 0,  # 新增：所有活动的总累计时间
            "总次数": 0,      # 新增：所有活动的总次数
            "累计罚款": 0     # 新增：累计罚款金额
        }

def reset_daily_data(chat_id: int, uid: int):
    """每日数据重置"""
    today = str(datetime.now().date())
    if group_data[str(chat_id)]["成员"][str(uid)]["最后更新"] != today:
        group_data[str(chat_id)]["成员"][str(uid)]["累计"] = {}
        group_data[str(chat_id)]["成员"][str(uid)]["次数"] = {}
        group_data[str(chat_id)]["成员"][str(uid)]["总累计时间"] = 0
        group_data[str(chat_id)]["成员"][str(uid)]["总次数"] = 0
        group_data[str(chat_id)]["成员"][str(uid)]["累计罚款"] = 0
        group_data[str(chat_id)]["成员"][str(uid)]["最后更新"] = today
        save_data()

def check_activity_limit(chat_id: int, uid: int, act: str):
    """检查活动次数是否达到上限"""
    init_user(chat_id, uid)
    reset_daily_data(chat_id, uid)
    
    current_count = group_data[str(chat_id)]["成员"][str(uid)]["次数"].get(act, 0)
    max_times = activity_limits[act]["max_times"]
    
    return current_count < max_times, current_count, max_times

def has_active_activity(chat_id: int, uid: int):
    """检查用户是否有活动正在进行"""
    init_user(chat_id, uid)
    user_data = group_data[str(chat_id)]["成员"][str(uid)]
    return user_data["活动"] is not None, user_data["活动"]

def load_data():
    """加载数据文件"""
    global group_data, activity_limits, fine_rates
    if os.path.exists(config.DATA_FILE):
        with open(config.DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            # 兼容旧版本数据
            for chat_id, chat_data in data.items():
                if "每日重置时间" not in chat_data:
                    chat_data["每日重置时间"] = {"hour": config.DAILY_RESET_HOUR, "minute": config.DAILY_RESET_MINUTE}
            group_data = data
    
    if os.path.exists(config.ACTIVITY_FILE):
        with open(config.ACTIVITY_FILE, "r", encoding="utf-8") as f:
            activity_data = json.load(f)
            # 兼容旧版本数据格式
            if isinstance(activity_data, dict) and "activities" in activity_data:
                activity_limits = activity_data.get("activities", config.DEFAULT_ACTIVITY_LIMITS.copy())
                fine_rates = activity_data.get("fines", config.DEFAULT_FINE_RATES.copy())
            else:
                activity_limits = activity_data
                fine_rates = config.DEFAULT_FINE_RATES.copy()

def save_data():
    """保存数据到文件"""
    with open(config.DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(group_data, f, ensure_ascii=False, indent=2, default=str)
    
    # 保存活动配置和罚款配置
    activity_data = {
        "activities": activity_limits,
        "fines": fine_rates
    }
    with open(config.ACTIVITY_FILE, "w", encoding="utf-8") as f:
        json.dump(activity_data, f, ensure_ascii=False, indent=2)

async def send_to_channel(chat_id: int, text: str):
    """发送消息到绑定频道"""
    channel_id = group_data.get(str(chat_id), {}).get("频道ID")
    if channel_id:
        try:
            await bot.send_message(channel_id, text)
        except Exception:
            pass

async def send_to_notification_group(chat_id: int, text: str):
    """发送消息到通知群组"""
    notification_group_id = group_data.get(str(chat_id), {}).get("通知群组ID")
    if notification_group_id:
        try:
            await bot.send_message(notification_group_id, text)
        except Exception:
            pass

async def send_all_notifications(chat_id: int, text: str):
    """发送到所有通知渠道"""
    await send_to_channel(chat_id, text)
    await send_to_notification_group(chat_id, text)

def calculate_fine(activity: str, overtime_minutes: float) -> int:
    """计算罚款金额 - 分段罚款"""
    if activity not in fine_rates:
        return 0
    
    fine_segments = fine_rates[activity]
    # 将时间段转换为整数并排序
    segments = sorted([int(time) for time in fine_segments.keys()])
    
    # 找到适用的罚款段
    applicable_fine = 0
    for segment in segments:
        if overtime_minutes <= segment:
            applicable_fine = fine_segments[str(segment)]
            break
    
    # 如果超过所有段，使用最后一个段的罚款
    if applicable_fine == 0 and segments:
        applicable_fine = fine_segments[str(segments[-1])]
    
    return applicable_fine

# ==================== 格式化消息函数 ====================
def format_user_link(user_id: int, user_name: str):
    """格式化用户链接（可点击联系）"""
    # 清理用户名中的特殊字符
    clean_name = user_name.replace('<', '').replace('>', '').replace('&', '').replace('"', '')
    return f'<a href="tg://user?id={user_id}">{clean_name}</a>'

def create_dashed_line(text: str) -> str:
    """创建自适应宽度的虚线分割线"""
    # 估算文本宽度（中文字符算2个宽度，英文字符算1个宽度）
    width = 0
    for char in text:
        if '\u4e00' <= char <= '\u9fff':  # 中文字符
            width += 2
        else:
            width += 1
    
    # 创建虚线，长度根据文本宽度调整（10-30个字符）
    dash_count = min(30, max(10, width))
    return "─" * dash_count

def format_activity_message(user_id: int, user_name: str, activity: str, time_str: str, 
                           count: int, max_times: int, time_limit: int):
    """格式化打卡消息"""
    first_line = f"👤 用户：{format_user_link(user_id, user_name)}"
    
    message = (
        f"{first_line}\n"
        f"✅ 打卡成功：{activity} - {time_str}\n"
        f"注意：这是您第 {count} 次{activity}（今日上限：{max_times}次）\n"
        f"本次活动时间限制：{time_limit} 分钟"
    )
    
    if count >= max_times:
        message += f"\n⚠️ 警告：本次结束后，您今日的{activity}次数将达到上限，请留意！"
    
    message += f"\n提示：活动完成后请及时点击'✅ 回座'按钮"
    
    return message

def format_back_message(user_id: int, user_name: str, activity: str, time_str: str, elapsed_time: str, 
                       total_activity_time: str, total_time: str, activity_counts: dict, total_count: int,
                       is_overtime: bool = False, overtime_seconds: int = 0, fine_amount: int = 0):
    """格式化回座消息 - 按照指定格式"""
    # 第一行用户信息
    first_line = f"👤 用户：{format_user_link(user_id, user_name)}"
    
    message = (
        f"{first_line}\n"
        f"✅ {time_str} 回座打卡成功\n"
        f"📝 活动：{activity}\n"
        f"⏱️ 本次活动耗时：{elapsed_time}\n"
        f"📊 今日累计{activity}时间：{total_activity_time}\n"
        f"📈 今日总计时：{total_time}\n"
    )
    
    # 添加超时警告和罚款
    if is_overtime:
        message += f"⚠️ 警告：您本次的活动已超时！\n超时时间：{format_time(overtime_seconds)}\n"
        if fine_amount > 0:
            message += f"罚款：{fine_amount} 元\n"
    
    # 创建自适应分割线（基于第一行长度）
    dashed_line = create_dashed_line(first_line)
    message += f"{dashed_line}\n"
    
    # 添加各活动次数（使用时钟图标）
    for act, count in activity_counts.items():
        if count > 0:
            message += f"⏰ 本日{act}次数：{count} 次\n"
    
    message += f"⏰ 今日总活动次数：{total_count} 次"
    
    return message

def format_timeout_message(user_id: int, user_name: str, activity: str, over_time_minutes: int):
    """格式化超时提醒消息"""
    first_line = f"👤 用户：{format_user_link(user_id, user_name)}"
    
    return (
        f"{first_line}\n"
        f"⚠️ 超时提醒：您的 {activity} 已经超时 {over_time_minutes} 分钟！请及时回座。"
    )

def format_warning_message(user_id: int, user_name: str, activity: str, message_type: str):
    """格式化警告消息"""
    first_line = f"👤 用户：{format_user_link(user_id, user_name)}"
    
    if message_type == "1min_warning":
        return f"{first_line}\n⚠️ 警告：您本次{activity}还有不到 1 分钟超时，请尽快回座！"
    elif message_type == "timeout":
        return f"{first_line}\n⚠️ 警告：您本次{activity}已超时，请尽快回座！"
    
    return f"{first_line}\n⚠️ 警告消息"

# ==================== 回复键盘（输入栏下方按钮） ====================
def get_main_keyboard(show_admin=False):
    """获取主回复键盘（显示在输入栏下方）"""
    keyboard = [
        [
            KeyboardButton(text="🍚 吃饭"),
            KeyboardButton(text="🚽 小厕"),
            KeyboardButton(text="🧻 大厕")
        ],
        [
            KeyboardButton(text="📚 学习"),
            KeyboardButton(text="💤 休息"),
            KeyboardButton(text="🚬 抽烟")
        ],
        [
            KeyboardButton(text="✅ 回座"),
            KeyboardButton(text="📊 我的记录"),
            KeyboardButton(text="🏆 排行榜")
        ]
    ]
    
    # 只有管理员才显示管理员面板按钮
    if show_admin:
        keyboard.append([KeyboardButton(text="👑 管理员面板")])
    
    return ReplyKeyboardMarkup(
        keyboard=keyboard,
        resize_keyboard=True,
        one_time_keyboard=False,
        input_field_placeholder="请选择操作或输入活动名称..."
    )

def get_admin_keyboard():
    """管理员专用键盘"""
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="👑 管理员面板"),
                KeyboardButton(text="📈 数据统计")
            ],
            [
                KeyboardButton(text="📤 导出数据"),
                KeyboardButton(text="📊 生成图表")
            ],
            [
                KeyboardButton(text="⚙️ 活动配置"),
                KeyboardButton(text="🔔 通知设置")
            ],
            [
                KeyboardButton(text="⏰ 重置时间"),
                KeyboardButton(text="💰 罚款设置"),
                KeyboardButton(text="🔙 返回主菜单")
            ]
        ],
        resize_keyboard=True
    )

# ==================== 活动定时提醒 ====================
async def activity_timer(chat_id: int, uid: int, act: str, limit: int):
    """活动定时提醒任务 - 修改为包含1分钟前提醒和超时提醒"""
    try:
        user_data = group_data[str(chat_id)]["成员"][str(uid)]
        nickname = user_data['昵称']
        
        # 1分钟前提醒
        warning_time = max(0, (limit - 1) * 60)  # 确保不为负数
        if warning_time > 0:
            await asyncio.sleep(warning_time)
            
            # 检查活动是否还在进行
            if group_data[str(chat_id)]["成员"][str(uid)]["活动"] == act:
                warning_msg = format_warning_message(uid, nickname, act, "1min_warning")
                await bot.send_message(chat_id, warning_msg, 
                                     reply_markup=get_main_keyboard(show_admin=is_admin(uid)),
                                     parse_mode="HTML")

        # 等待剩余时间到限制
        remaining_time = 60  # 最后1分钟
        await asyncio.sleep(remaining_time)

        # 超时提醒
        if group_data[str(chat_id)]["成员"][str(uid)]["活动"] == act:
            timeout_msg = format_warning_message(uid, nickname, act, "timeout")
            await bot.send_message(chat_id, timeout_msg, 
                                 reply_markup=get_main_keyboard(show_admin=is_admin(uid)),
                                 parse_mode="HTML")
            
            notification_msg = f"⏰ [超时提醒]\n群组ID: {chat_id}\n用户: {nickname}\n活动: {act}\n状态: 已超时"
            await send_all_notifications(chat_id, notification_msg)

        # 超时循环提醒 - 不再强制回座，只持续提醒
        over_time_minutes = 0
        while group_data[str(chat_id)]["成员"][str(uid)]["活动"] == act:
            await asyncio.sleep(config.REMINDER_INTERVAL * 60)
            over_time_minutes += config.REMINDER_INTERVAL
            
            if group_data[str(chat_id)]["成员"][str(uid)]["活动"] == act:
                group_msg = format_timeout_message(uid, nickname, act, over_time_minutes)
                await bot.send_message(chat_id, group_msg, 
                                     reply_markup=get_main_keyboard(show_admin=is_admin(uid)),
                                     parse_mode="HTML")
                
                notification_msg = f"⚠️ [超时提醒]\n群组ID: {chat_id}\n用户: {nickname}\n活动: {act}\n超时: {over_time_minutes} 分钟"
                await send_all_notifications(chat_id, notification_msg)
            
    except Exception as e:
        print(f"定时器错误: {e}")

# ==================== 核心打卡功能 ====================
async def start_activity(message: types.Message, act: str):
    """开始活动打卡 - 增加次数上限检查和活动冲突检查"""
    chat_id = message.chat.id
    uid = message.from_user.id
    name = message.from_user.full_name
    now = datetime.now()

    # 检查活动是否存在
    if act not in activity_limits:
        await message.answer(
            f"❌ 活动 '{act}' 不存在，请使用下方按钮选择活动",
            reply_markup=get_main_keyboard(show_admin=is_admin(uid))
        )
        return

    # 检查是否有活动正在进行
    has_active, current_act = has_active_activity(chat_id, uid)
    if has_active:
        await message.answer(
            config.MESSAGES["has_activity"].format(current_act),
            reply_markup=get_main_keyboard(show_admin=is_admin(uid))
        )
        return

    # 检查次数限制
    can_start, current_count, max_times = check_activity_limit(chat_id, uid, act)
    
    if not can_start:
        await message.answer(
            config.MESSAGES["max_times_reached"].format(act, max_times),
            reply_markup=get_main_keyboard(show_admin=is_admin(uid))
        )
        return

    init_user(chat_id, uid)
    reset_daily_data(chat_id, uid)

    # 更新用户数据
    group_data[str(chat_id)]["成员"][str(uid)]["昵称"] = name
    count = current_count + 1
    group_data[str(chat_id)]["成员"][str(uid)]["活动"] = act
    group_data[str(chat_id)]["成员"][str(uid)]["开始时间"] = str(now)
    group_data[str(chat_id)]["成员"][str(uid)]["次数"][act] = count
    save_data()

    # 启动定时器
    key = f"{chat_id}-{uid}"
    if key in tasks and not tasks[key].done():
        tasks[key].cancel()
    tasks[key] = asyncio.create_task(activity_timer(chat_id, uid, act, activity_limits[act]["time_limit"]))

    # 构建回复消息
    await message.answer(
        format_activity_message(uid, name, act, now.strftime('%m/%d %H:%M:%S'), 
                              count, max_times, activity_limits[act]["time_limit"]),
        reply_markup=get_main_keyboard(show_admin=is_admin(uid)),
        parse_mode="HTML"
    )

# ==================== 消息处理器 ====================
@dp.message(Command("start"))
async def cmd_start(message: types.Message):
    """开始命令 - 自动显示按钮"""
    uid = message.from_user.id
    await message.answer(
        config.MESSAGES["welcome"],
        reply_markup=get_main_keyboard(show_admin=is_admin(uid))
    )

@dp.message(Command("menu"))
async def cmd_menu(message: types.Message):
    """显示主菜单"""
    uid = message.from_user.id
    await message.answer("📋 主菜单", reply_markup=get_main_keyboard(show_admin=is_admin(uid)))

@dp.message(Command("admin"))
async def cmd_admin(message: types.Message):
    """管理员命令"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    await message.answer("👑 管理员面板", reply_markup=get_admin_keyboard())

# ==================== 文本命令处理（支持直接输入活动名称） ====================
@dp.message(lambda message: message.text.strip() in ["吃饭", "小厕", "大厕", "学习", "休息", "抽烟"])
async def handle_text_commands(message: types.Message):
    """处理文本命令打卡"""
    act = message.text.strip()
    await start_activity(message, act)

# ==================== 按钮文本处理 ====================
@dp.message(lambda message: message.text in ["🍚 吃饭", "🚽 小厕", "🧻 大厕", "📚 学习", "💤 休息", "🚬 抽烟"])
async def handle_activity_buttons(message: types.Message):
    """处理活动按钮点击"""
    activity_mapping = {
        "🍚 吃饭": "吃饭",
        "🚽 小厕": "小厕",
        "🧻 大厕": "大厕",
        "📚 学习": "学习",
        "💤 休息": "休息",
        "🚬 抽烟": "抽烟"
    }
    
    act = activity_mapping[message.text]
    await start_activity(message, act)

@dp.message(lambda message: message.text == "✅ 回座")
async def handle_back_button(message: types.Message):
    """处理回座按钮点击"""
    await process_back(message)

@dp.message(lambda message: message.text == "📊 我的记录")
async def handle_history_button(message: types.Message):
    """处理我的记录按钮点击"""
    await show_history(message)

@dp.message(lambda message: message.text == "🏆 排行榜")
async def handle_rank_button(message: types.Message):
    """处理排行榜按钮点击"""
    await show_rank(message)

@dp.message(lambda message: message.text == "🔙 返回主菜单")
async def handle_back_menu(message: types.Message):
    """返回主菜单"""
    uid = message.from_user.id
    await message.answer("📋 主菜单", reply_markup=get_main_keyboard(show_admin=is_admin(uid)))

# ==================== 用户功能 ====================
async def show_history(message: types.Message):
    """显示用户历史记录"""
    chat_id = message.chat.id
    uid = message.from_user.id
    init_user(chat_id, uid)
    reset_daily_data(chat_id, uid)
    
    user = group_data[str(chat_id)]["成员"][str(uid)]
    first_line = f"👤 用户：{format_user_link(uid, user['昵称'])}"
    text = f"{first_line}\n📊 今日记录：\n\n"
    
    has_records = False
    for act in activity_limits.keys():
        total_time = user["累计"].get(act, 0)
        count = user["次数"].get(act, 0)
        max_times = activity_limits[act]["max_times"]
        if total_time > 0 or count > 0:
            status = "✅" if count < max_times else "❌"
            text += f"• {act}：{format_time(int(total_time))}，次数：{count}/{max_times} {status}\n"
            has_records = True
    
    # 添加总统计和罚款
    total_time_all = user.get("总累计时间", 0)
    total_count_all = user.get("总次数", 0)
    total_fine = user.get("累计罚款", 0)
    
    text += f"\n📈 今日总统计：\n"
    text += f"• 总累计时间：{format_time(int(total_time_all))}\n"
    text += f"• 总活动次数：{total_count_all} 次\n"
    if total_fine > 0:
        text += f"• 累计罚款：{total_fine} 元"
    
    if not has_records and total_count_all == 0:
        text += "暂无记录，请先进行打卡活动"
        
    await message.answer(text, reply_markup=get_main_keyboard(show_admin=is_admin(uid)), parse_mode="HTML")

async def show_rank(message: types.Message):
    """显示排行榜"""
    chat_id = message.chat.id
    uid = message.from_user.id
    init_group(chat_id)
    
    rank_text = "🏆 今日活动排行榜\n\n"
    
    for act in activity_limits.keys():
        # 收集用户数据
        user_times = []
        for user_uid, user_data in group_data[str(chat_id)]["成员"].items():
            total_time = user_data["累计"].get(act, 0)
            if total_time > 0:
                user_times.append((user_data['昵称'], user_data['用户ID'], total_time))
        
        # 排序并取前5名
        user_times.sort(key=lambda x: x[2], reverse=True)
        
        if user_times:
            rank_text += f"📈 {act}：\n"
            for i, (name, user_id, time_sec) in enumerate(user_times[:3], 1):
                rank_text += f"  {i}. {format_user_link(user_id, name)} - {format_time(int(time_sec))}\n"
            rank_text += "\n"
    
    await message.answer(rank_text, reply_markup=get_main_keyboard(show_admin=is_admin(uid)), parse_mode="HTML")

# ==================== 回座功能 ====================
async def process_back(message: types.Message):
    """回座打卡 - 按照指定格式显示"""
    chat_id = message.chat.id
    uid = message.from_user.id
    now = datetime.now()

    init_user(chat_id, uid)
    reset_daily_data(chat_id, uid)

    user_data = group_data[str(chat_id)]["成员"][str(uid)]
    if not user_data["活动"]:
        await message.answer(config.MESSAGES["no_activity"], reply_markup=get_main_keyboard(show_admin=is_admin(uid)))
        return

    act = user_data["活动"]
    start_time = datetime.fromisoformat(user_data["开始时间"])
    elapsed = (now - start_time).total_seconds()
    total_activity_time = user_data["累计"].get(act, 0) + elapsed
    
    # 检查是否超时
    time_limit_seconds = activity_limits[act]["time_limit"] * 60
    is_overtime = elapsed > time_limit_seconds
    overtime_seconds = max(0, int(elapsed - time_limit_seconds))
    
    # 计算罚款（分段罚款）
    fine_amount = 0
    if is_overtime and overtime_seconds > 0:
        overtime_minutes = overtime_seconds / 60
        fine_amount = calculate_fine(act, overtime_minutes)
        # 更新累计罚款
        user_data["累计罚款"] = user_data.get("累计罚款", 0) + fine_amount
    
    # 更新活动数据
    user_data["累计"][act] = total_activity_time
    current_count = user_data["次数"][act]
    
    # 更新总统计数据
    user_data["总累计时间"] = user_data.get("总累计时间", 0) + elapsed
    user_data["总次数"] = user_data.get("总次数", 0) + 1
    
    user_data["活动"] = None
    user_data["开始时间"] = None
    save_data()

    # 取消定时任务
    key = f"{chat_id}-{uid}"
    if key in tasks and not tasks[key].done():
        tasks[key].cancel()

    # 构建活动次数字典
    activity_counts = {}
    for activity in activity_limits.keys():
        activity_counts[activity] = user_data["次数"].get(activity, 0)

    await message.answer(
        format_back_message(
            user_id=uid,
            user_name=user_data['昵称'],
            activity=act,
            time_str=now.strftime('%m/%d %H:%M:%S'),
            elapsed_time=format_time(int(elapsed)),
            total_activity_time=format_time(int(total_activity_time)),
            total_time=format_time(int(user_data["总累计时间"])),
            activity_counts=activity_counts,
            total_count=user_data["总次数"],
            is_overtime=is_overtime,
            overtime_seconds=overtime_seconds,
            fine_amount=fine_amount
        ),
        reply_markup=get_main_keyboard(show_admin=is_admin(uid)),
        parse_mode="HTML"
    )

# ==================== 管理员按钮处理 ====================
@dp.message(lambda message: message.text == "👑 管理员面板")
async def handle_admin_panel(message: types.Message):
    """处理管理员面板按钮"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    
    admin_text = (
        "👑 管理员面板\n\n"
        "可用命令：\n"
        "• /setchannel <频道ID> - 绑定提醒频道\n"
        "• /setgroup <群组ID> - 绑定通知群组\n"
        "• /addactivity <活动名> <次数> <分钟> - 添加新活动\n"
        "• /set <用户ID> <活动> <分钟> - 设置用户时间\n"
        "• /reset <用户ID> - 重置用户数据\n"
        "• /setresettime <小时> <分钟> - 设置每日重置时间\n"
        "• /setfine <活动名> <时间段> <金额> - 设置活动罚款费率\n\n"
        "点击下方按钮查看数据："
    )
    await message.answer(admin_text, reply_markup=get_admin_keyboard())

@dp.message(lambda message: message.text == "📈 数据统计")
async def handle_data_stats(message: types.Message):
    """处理数据统计按钮"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    await data_stats(message)

@dp.message(lambda message: message.text == "📤 导出数据")
async def handle_export_data(message: types.Message):
    """处理导出数据按钮"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    await export_data(message)

@dp.message(lambda message: message.text == "📊 生成图表")
async def handle_generate_chart(message: types.Message):
    """处理生成图表按钮"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    await generate_chart(message)

@dp.message(lambda message: message.text == "⚙️ 活动配置")
async def handle_activity_config(message: types.Message, state: FSMContext):
    """处理活动配置按钮"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    await edit_activity_start(message, state)

@dp.message(lambda message: message.text == "🔔 通知设置")
async def handle_notification_settings(message: types.Message, state: FSMContext):
    """处理通知设置按钮"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    await notification_settings_menu(message, state)

@dp.message(lambda message: message.text == "⏰ 重置时间")
async def handle_reset_time(message: types.Message, state: FSMContext):
    """处理重置时间设置按钮"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    await set_reset_time_start(message, state)

@dp.message(lambda message: message.text == "💰 罚款设置")
async def handle_fine_settings(message: types.Message, state: FSMContext):
    """处理罚款设置按钮"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
    await fine_settings_menu(message, state)

# ==================== 罚款设置功能 ====================
async def fine_settings_menu(message: types.Message, state: FSMContext):
    """罚款设置菜单"""
    fine_text = "💰 当前罚款费率设置（分段罚款）：\n\n"
    for act, rates in fine_rates.items():
        fine_text += f"🔸 {act}:\n"
        for time_segment, amount in rates.items():
            fine_text += f"   • {time_segment}分钟内: {amount} 元\n"
    
    fine_text += "\n请选择要修改罚款费率的活动："
    
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=f"设置{act}罚款") for act in list(fine_rates.keys())[:3]],
            [KeyboardButton(text=f"设置{act}罚款") for act in list(fine_rates.keys())[3:]],
            [KeyboardButton(text="🔙 返回管理员面板")]
        ],
        resize_keyboard=True
    )
    
    await message.answer(fine_text, reply_markup=keyboard)
    await state.set_state(AdminStates.waiting_for_fine_activity)

@dp.message(AdminStates.waiting_for_fine_activity)
async def process_fine_activity_selection(message: types.Message, state: FSMContext):
    """处理罚款活动选择"""
    text = message.text
    
    if text == "🔙 返回管理员面板":
        await state.clear()
        await message.answer("已返回管理员面板", reply_markup=get_admin_keyboard())
        return
    
    # 处理设置罚款
    for act in fine_rates.keys():
        if text == f"设置{act}罚款":
            await state.update_data(fine_activity=act)
            current_rates = fine_rates[act]
            
            rates_text = f"当前罚款费率:\n"
            for time_seg, amount in current_rates.items():
                rates_text += f"• {time_seg}分钟内: {amount} 元\n"
            
            await message.answer(
                f"正在设置活动: {act}\n{rates_text}\n"
                f"请输入时间段（分钟，数字）：",
                reply_markup=ReplyKeyboardRemove()
            )
            await state.set_state(AdminStates.waiting_for_fine_time_segment)
            return
    
    await message.answer("请选择有效的活动")

@dp.message(AdminStates.waiting_for_fine_time_segment)
async def set_fine_time_segment(message: types.Message, state: FSMContext):
    """设置罚款时间段"""
    try:
        time_segment = int(message.text)
        if time_segment > 0:
            await state.update_data(fine_time_segment=time_segment)
            await message.answer(f"✅ 时间段设置为: {time_segment} 分钟\n\n请输入罚款金额（数字）：")
            await state.set_state(AdminStates.waiting_for_fine_amount)
        else:
            await message.answer("❌ 时间段必须大于0！")
    except ValueError:
        await message.answer("❌ 请输入有效的数字！")

@dp.message(AdminStates.waiting_for_fine_amount)
async def set_fine_amount(message: types.Message, state: FSMContext):
    """设置罚款金额"""
    try:
        fine_amount = int(message.text)
        if fine_amount >= 0:
            data = await state.get_data()
            activity_name = data['fine_activity']
            time_segment = data['fine_time_segment']
            
            # 更新罚款费率
            if activity_name not in fine_rates:
                fine_rates[activity_name] = {}
            
            fine_rates[activity_name][str(time_segment)] = fine_amount
            save_data()
            
            await message.answer(
                f"✅ 罚款费率更新成功！\n\n"
                f"活动: {activity_name}\n"
                f"时间段: {time_segment} 分钟内\n"
                f"罚款金额: {fine_amount} 元",
                reply_markup=get_admin_keyboard()
            )
            await state.clear()
        else:
            await message.answer("❌ 罚款金额不能为负数！")
    except ValueError:
        await message.answer("❌ 请输入有效的数字！")

# ==================== 管理员FSM功能实现 ====================
async def edit_activity_start(message: types.Message, state: FSMContext):
    """开始修改活动配置"""
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text=f"修改{act}") for act in list(activity_limits.keys())[:3]],
            [KeyboardButton(text=f"修改{act}") for act in list(activity_limits.keys())[3:]],
            [KeyboardButton(text="添加新活动"), KeyboardButton(text="🔙 返回管理员面板")]
        ],
        resize_keyboard=True
    )
    
    config_text = "📋 当前活动配置：\n\n"
    for act, limits in activity_limits.items():
        config_text += f"🔸 {act}: 最大{limits['max_times']}次, {limits['time_limit']}分钟\n"
    
    await message.answer(f"{config_text}\n请选择要修改的活动：", reply_markup=keyboard)
    await state.set_state(AdminStates.waiting_for_activity_name)

@dp.message(AdminStates.waiting_for_activity_name)
async def process_activity_selection(message: types.Message, state: FSMContext):
    """处理活动选择"""
    text = message.text
    
    if text == "🔙 返回管理员面板":
        await state.clear()
        await message.answer("已返回管理员面板", reply_markup=get_admin_keyboard())
        return
    elif text == "添加新活动":
        await message.answer("请输入新活动的名称：", reply_markup=ReplyKeyboardRemove())
        await state.set_state(AdminStates.waiting_for_new_activity_name)
        return
    
    # 处理修改现有活动
    for act in activity_limits.keys():
        if text == f"修改{act}":
            await state.update_data(activity_name=act)
            current_limits = activity_limits[act]
            await message.answer(
                f"正在修改活动: {act}\n"
                f"当前设置: 最大次数 {current_limits['max_times']}, 时间限制 {current_limits['time_limit']} 分钟\n\n"
                f"请输入新的最大次数（数字）：",
                reply_markup=ReplyKeyboardRemove()
            )
            await state.set_state(AdminStates.waiting_for_max_times)
            return
    
    await message.answer("请选择有效的活动")

@dp.message(AdminStates.waiting_for_max_times)
async def set_max_times(message: types.Message, state: FSMContext):
    """设置最大次数"""
    try:
        max_times = int(message.text)
        await state.update_data(max_times=max_times)
        await message.answer(f"✅ 最大次数设置为: {max_times}\n\n请输入新的时间限制（分钟，数字）：")
        await state.set_state(AdminStates.waiting_for_time_limit)
    except ValueError:
        await message.answer("❌ 请输入有效的数字！")

@dp.message(AdminStates.waiting_for_time_limit)
async def set_time_limit(message: types.Message, state: FSMContext):
    """设置时间限制"""
    try:
        time_limit = int(message.text)
        data = await state.get_data()
        activity_name = data['activity_name']
        max_times = data['max_times']
        
        # 更新配置
        activity_limits[activity_name] = {
            "max_times": max_times,
            "time_limit": time_limit
        }
        save_data()
        
        await message.answer(
            f"✅ 活动配置更新成功！\n\n"
            f"活动: {activity_name}\n"
            f"最大次数: {max_times}\n"
            f"时间限制: {time_limit} 分钟",
            reply_markup=get_admin_keyboard()
        )
        await state.clear()
    except ValueError:
        await message.answer("❌ 请输入有效的数字！")

@dp.message(AdminStates.waiting_for_new_activity_name)
async def set_new_activity_name(message: types.Message, state: FSMContext):
    """设置新活动名称"""
    new_activity = message.text.strip()
    if new_activity in activity_limits:
        await message.answer("❌ 该活动已存在，请选择其他名称")
        return
    
    await state.update_data(new_activity_name=new_activity)
    await message.answer(f"新活动名称: {new_activity}\n\n请输入最大次数（数字）：")
    await state.set_state(AdminStates.waiting_for_new_max_times)

@dp.message(AdminStates.waiting_for_new_max_times)
async def set_new_max_times(message: types.Message, state: FSMContext):
    """设置新活动最大次数"""
    try:
        max_times = int(message.text)
        await state.update_data(new_max_times=max_times)
        await message.answer(f"✅ 最大次数设置为: {max_times}\n\n请输入时间限制（分钟，数字）：")
        await state.set_state(AdminStates.waiting_for_new_time_limit)
    except ValueError:
        await message.answer("❌ 请输入有效的数字！")

@dp.message(AdminStates.waiting_for_new_time_limit)
async def set_new_time_limit(message: types.Message, state: FSMContext):
    """设置新活动时间限制"""
    try:
        time_limit = int(message.text)
        data = await state.get_data()
        activity_name = data['new_activity_name']
        max_times = data['new_max_times']
        
        # 添加新活动
        activity_limits[activity_name] = {
            "max_times": max_times,
            "time_limit": time_limit
        }
        # 同时设置默认罚款费率
        fine_rates[activity_name] = {"30": 100}  # 默认30分钟内100元
        save_data()
        
        await message.answer(
            f"✅ 新活动添加成功！\n\n"
            f"活动: {activity_name}\n"
            f"最大次数: {max_times}\n"
            f"时间限制: {time_limit} 分钟\n"
            f"默认罚款费率: 30分钟内 100 元",
            reply_markup=get_admin_keyboard()
        )
        await state.clear()
    except ValueError:
        await message.answer("❌ 请输入有效的数字！")

async def set_reset_time_start(message: types.Message, state: FSMContext):
    """开始设置重置时间"""
    chat_id = message.chat.id
    init_group(chat_id)
    reset_time = group_data[str(chat_id)]["每日重置时间"]
    
    await message.answer(
        f"⏰ 当前每日重置时间：{reset_time['hour']:02d}:{reset_time['minute']:02d}\n\n"
        f"请输入新的重置小时（0-23）：",
        reply_markup=ReplyKeyboardRemove()
    )
    await state.set_state(AdminStates.waiting_for_reset_hour)

@dp.message(AdminStates.waiting_for_reset_hour)
async def set_reset_hour(message: types.Message, state: FSMContext):
    """设置重置小时"""
    try:
        hour = int(message.text)
        if 0 <= hour <= 23:
            await state.update_data(reset_hour=hour)
            await message.answer(f"✅ 重置小时设置为: {hour:02d}\n\n请输入新的重置分钟（0-59）：")
            await state.set_state(AdminStates.waiting_for_reset_minute)
        else:
            await message.answer("❌ 小时必须在0-23之间！")
    except ValueError:
        await message.answer("❌ 请输入有效的数字！")

@dp.message(AdminStates.waiting_for_reset_minute)
async def set_reset_minute(message: types.Message, state: FSMContext):
    """设置重置分钟"""
    try:
        minute = int(message.text)
        if 0 <= minute <= 59:
            data = await state.get_data()
            hour = data['reset_hour']
            chat_id = message.chat.id
            
            init_group(chat_id)
            group_data[str(chat_id)]["每日重置时间"] = {"hour": hour, "minute": minute}
            save_data()
            
            await message.answer(
                f"✅ 每日重置时间已更新为：{hour:02d}:{minute:02d}\n\n"
                f"下次重置将在设定的时间自动执行。",
                reply_markup=get_admin_keyboard()
            )
            await state.clear()
        else:
            await message.answer("❌ 分钟必须在0-59之间！")
    except ValueError:
        await message.answer("❌ 请输入有效的数字！")

async def notification_settings_menu(message: types.Message, state: FSMContext):
    """通知设置菜单"""
    chat_id = message.chat.id
    init_group(chat_id)
    group_config = group_data[str(chat_id)]
    
    current_settings = (
        f"🔔 当前通知设置：\n"
        f"频道ID: {group_config.get('频道ID', '未设置')}\n"
        f"通知群组ID: {group_config.get('通知群组ID', '未设置')}\n\n"
        f"请选择操作："
    )
    
    keyboard = ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="设置频道"), KeyboardButton(text="设置通知群组")],
            [KeyboardButton(text="清除频道"), KeyboardButton(text="清除通知群组")],
            [KeyboardButton(text="🔙 返回管理员面板")]
        ],
        resize_keyboard=True
    )
    
    await message.answer(current_settings, reply_markup=keyboard)

@dp.message(lambda message: message.text in ["设置频道", "设置通知群组", "清除频道", "清除通知群组", "🔙 返回管理员面板"])
async def handle_notification_actions(message: types.Message, state: FSMContext):
    """处理通知设置操作"""
    text = message.text
    chat_id = message.chat.id
    
    if text == "🔙 返回管理员面板":
        await state.clear()
        await message.answer("已返回管理员面板", reply_markup=get_admin_keyboard())
        return
    elif text == "设置频道":
        await message.answer("请输入频道ID（格式如 -1001234567890）：", reply_markup=ReplyKeyboardRemove())
        await state.set_state(AdminStates.waiting_for_channel_id)
    elif text == "设置通知群组":
        await message.answer("请输入通知群组ID（格式如 -1001234567890）：", reply_markup=ReplyKeyboardRemove())
        await state.set_state(AdminStates.waiting_for_group_id)
    elif text == "清除频道":
        init_group(chat_id)
        group_data[str(chat_id)]["频道ID"] = None
        save_data()
        await message.answer("✅ 已清除频道设置", reply_markup=get_admin_keyboard())
    elif text == "清除通知群组":
        init_group(chat_id)
        group_data[str(chat_id)]["通知群组ID"] = None
        save_data()
        await message.answer("✅ 已清除通知群组设置", reply_markup=get_admin_keyboard())

@dp.message(AdminStates.waiting_for_channel_id)
async def set_channel_id(message: types.Message, state: FSMContext):
    """设置频道ID"""
    try:
        channel_id = int(message.text)
        chat_id = message.chat.id
        init_group(chat_id)
        group_data[str(chat_id)]["频道ID"] = channel_id
        save_data()
        await message.answer(f"✅ 已绑定提醒频道：{channel_id}", reply_markup=get_admin_keyboard())
        await state.clear()
    except ValueError:
        await message.answer("❌ 请输入有效的频道ID！")

@dp.message(AdminStates.waiting_for_group_id)
async def set_group_id(message: types.Message, state: FSMContext):
    """设置通知群组ID"""
    try:
        group_id = int(message.text)
        chat_id = message.chat.id
        init_group(chat_id)
        group_data[str(chat_id)]["通知群组ID"] = group_id
        save_data()
        await message.answer(f"✅ 已绑定通知群组：{group_id}", reply_markup=get_admin_keyboard())
        await state.clear()
    except ValueError:
        await message.answer("❌ 请输入有效的群组ID！")

# ==================== 管理员命令功能 ====================
@dp.message(Command("setchannel"))
async def cmd_setchannel(message: types.Message):
    """绑定提醒频道"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
        
    chat_id = message.chat.id
    args = message.text.split(maxsplit=1)
    
    if len(args) < 2:
        await message.answer(config.MESSAGES["setchannel_usage"], reply_markup=get_main_keyboard())
        return
        
    try:
        channel_id = int(args[1].strip())
        init_group(chat_id)
        group_data[str(chat_id)]["频道ID"] = channel_id
        save_data()
        await message.answer(f"✅ 已绑定超时提醒推送频道：{channel_id}", reply_markup=get_main_keyboard(show_admin=True))
    except ValueError:
        await message.answer("❌ 频道ID必须是数字", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("setgroup"))
async def cmd_setgroup(message: types.Message):
    """绑定通知群组"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
        
    chat_id = message.chat.id
    args = message.text.split(maxsplit=1)
    
    if len(args) < 2:
        await message.answer(config.MESSAGES["setgroup_usage"], reply_markup=get_main_keyboard())
        return
        
    try:
        group_id = int(args[1].strip())
        init_group(chat_id)
        group_data[str(chat_id)]["通知群组ID"] = group_id
        save_data()
        await message.answer(f"✅ 已绑定超时通知群组：{group_id}", reply_markup=get_main_keyboard(show_admin=True))
    except ValueError:
        await message.answer("❌ 群组ID必须是数字", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("addactivity"))
async def cmd_addactivity(message: types.Message):
    """添加新活动"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
        
    args = message.text.split()
    if len(args) != 4:
        await message.answer(config.MESSAGES["addactivity_usage"], reply_markup=get_main_keyboard(show_admin=True))
        return
        
    try:
        act, max_times, time_limit = args[1], int(args[2]), int(args[3])
        activity_limits[act] = {"max_times": max_times, "time_limit": time_limit}
        # 同时设置默认罚款费率
        fine_rates[act] = {"30": 100}  # 默认30分钟内100元
        save_data()
        await message.answer(f"✅ 已添加新活动 {act}，次数上限 {max_times}，时间限制 {time_limit} 分钟，默认罚款费率 30分钟内 100 元", reply_markup=get_main_keyboard(show_admin=True))
    except Exception as e:
        await message.answer(f"❌ 添加活动失败：{e}", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("set"))
async def cmd_set(message: types.Message):
    """设置用户数据"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
        
    args = message.text.split()
    if len(args) != 4:
        await message.answer(config.MESSAGES["set_usage"], reply_markup=get_main_keyboard(show_admin=True))
        return
        
    try:
        uid, act, minutes = args[1], args[2], args[3]
        chat_id = message.chat.id
        
        init_user(chat_id, int(uid))
        group_data[str(chat_id)]["成员"][str(uid)]["累计"][act] = int(minutes) * 60
        # 同时设置次数
        group_data[str(chat_id)]["成员"][str(uid)]["次数"][act] = int(minutes) // 30  # 估算次数
        save_data()
        
        await message.answer(f"✅ 已设置用户 {uid} 的 {act} 累计时间为 {minutes} 分钟", reply_markup=get_main_keyboard(show_admin=True))
    except Exception as e:
        await message.answer(f"❌ 设置失败：{e}", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("reset"))
async def cmd_reset(message: types.Message):
    """重置用户数据"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
        
    args = message.text.split()
    if len(args) != 2:
        await message.answer(config.MESSAGES["reset_usage"], reply_markup=get_main_keyboard(show_admin=True))
        return
        
    try:
        uid = args[1]
        chat_id = message.chat.id
        
        init_user(chat_id, int(uid))
        group_data[str(chat_id)]["成员"][str(uid)]["累计"] = {}
        group_data[str(chat_id)]["成员"][str(uid)]["次数"] = {}
        group_data[str(chat_id)]["成员"][str(uid)]["总累计时间"] = 0
        group_data[str(chat_id)]["成员"][str(uid)]["总次数"] = 0
        group_data[str(chat_id)]["成员"][str(uid)]["累计罚款"] = 0
        save_data()
        
        await message.answer(f"✅ 已重置用户 {uid} 的今日数据", reply_markup=get_main_keyboard(show_admin=True))
    except Exception as e:
        await message.answer(f"❌ 重置失败：{e}", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("setresettime"))
async def cmd_setresettime(message: types.Message):
    """设置每日重置时间"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
        
    args = message.text.split()
    if len(args) != 3:
        await message.answer(config.MESSAGES["setresettime_usage"], reply_markup=get_main_keyboard(show_admin=True))
        return
        
    try:
        hour = int(args[1])
        minute = int(args[2])
        
        if 0 <= hour <= 23 and 0 <= minute <= 59:
            chat_id = message.chat.id
            init_group(chat_id)
            group_data[str(chat_id)]["每日重置时间"] = {"hour": hour, "minute": minute}
            save_data()
            
            await message.answer(f"✅ 每日重置时间已设置为：{hour:02d}:{minute:02d}", reply_markup=get_main_keyboard(show_admin=True))
        else:
            await message.answer("❌ 小时必须在0-23之间，分钟必须在0-59之间！", reply_markup=get_main_keyboard(show_admin=True))
    except ValueError:
        await message.answer("❌ 请输入有效的数字！", reply_markup=get_main_keyboard(show_admin=True))

@dp.message(Command("setfine"))
async def cmd_setfine(message: types.Message):
    """设置活动罚款费率"""
    if not is_admin(message.from_user.id):
        await message.answer(config.MESSAGES["no_permission"], reply_markup=get_main_keyboard())
        return
        
    args = message.text.split()
    if len(args) != 4:
        await message.answer(config.MESSAGES["setfine_usage"], reply_markup=get_main_keyboard(show_admin=True))
        return
        
    try:
        act = args[1]
        time_segment = args[2]
        fine_amount = int(args[3])
        
        if act not in fine_rates:
            await message.answer(f"❌ 活动 '{act}' 不存在！", reply_markup=get_main_keyboard(show_admin=True))
            return
            
        if fine_amount < 0:
            await message.answer("❌ 罚款金额不能为负数！", reply_markup=get_main_keyboard(show_admin=True))
            return
        
        # 更新罚款费率
        if act not in fine_rates:
            fine_rates[act] = {}
        
        fine_rates[act][time_segment] = fine_amount
        save_data()
        
        await message.answer(f"✅ 已设置活动 '{act}' 在 {time_segment} 分钟内的罚款费率为 {fine_amount} 元", reply_markup=get_main_keyboard(show_admin=True))
    except ValueError:
        await message.answer("❌ 请输入有效的数字！", reply_markup=get_main_keyboard(show_admin=True))
    except Exception as e:
        await message.answer(f"❌ 设置失败：{e}", reply_markup=get_main_keyboard(show_admin=True))

# ==================== 管理员数据功能 ====================
async def data_stats(message: types.Message):
    """数据统计"""
    chat_id = message.chat.id
    init_group(chat_id)
    
    total_users = len(group_data[str(chat_id)]["成员"])
    active_today = 0
    total_activities = 0
    total_time_all = 0
    total_fines = 0
    
    for user_data in group_data[str(chat_id)]["成员"].values():
        if user_data["累计"]:  # 有活动记录
            active_today += 1
        total_activities += sum(user_data["次数"].values())
        total_time_all += user_data.get("总累计时间", 0)
        total_fines += user_data.get("累计罚款", 0)
    
    stats_text = f"📈 群组数据统计\n\n"
    stats_text += f"👥 总用户数: {total_users}\n"
    stats_text += f"✅ 今日活跃用户: {active_today}\n"
    stats_text += f"📊 今日总活动次数: {total_activities}\n"
    stats_text += f"⏱️ 今日总累计时间: {format_time(int(total_time_all))}\n"
    stats_text += f"💰 今日总罚款金额: {total_fines} 元\n"
    
    # 添加各活动统计
    stats_text += f"\n📋 各活动统计：\n"
    for act in activity_limits.keys():
        act_count = 0
        act_time = 0
        for user_data in group_data[str(chat_id)]["成员"].values():
            act_count += user_data["次数"].get(act, 0)
            act_time += user_data["累计"].get(act, 0)
        stats_text += f"• {act}: {act_count} 次, {format_time(int(act_time))}\n"
    
    await message.answer(stats_text, reply_markup=get_admin_keyboard())

async def export_data(message: types.Message):
    """导出数据"""
    chat_id = message.chat.id
    file_name = f"group_{chat_id}_export.csv"
    
    try:
        with open(file_name, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["用户ID", "昵称", "活动", "累计时间(秒)", "次数", "时间限制", "最大次数", "总累计时间", "总次数", "累计罚款"])
            
            for uid, user_data in group_data[str(chat_id)]["成员"].items():
                for act in activity_limits.keys():
                    writer.writerow([
                        uid, 
                        user_data["昵称"], 
                        act, 
                        user_data["累计"].get(act, 0), 
                        user_data["次数"].get(act, 0),
                        activity_limits[act]["time_limit"],
                        activity_limits[act]["max_times"],
                        user_data.get("总累计时间", 0),
                        user_data.get("总次数", 0),
                        user_data.get("累计罚款", 0)
                    ])
                    
        await message.answer_document(InputFile(file_name), reply_markup=get_admin_keyboard())
    except Exception as e:
        await message.answer(f"❌ 导出失败：{e}", reply_markup=get_admin_keyboard())

async def generate_chart(message: types.Message):
    """生成图表"""
    chat_id = message.chat.id
    
    # 收集数据
    labels = []
    values = []
    
    for uid, user_data in group_data[str(chat_id)]["成员"].items():
        for act in activity_limits.keys():
            time_minutes = user_data["累计"].get(act, 0) / 60
            if time_minutes > 0:  # 只显示有数据的
                labels.append(f"{user_data['昵称']}-{act}")
                values.append(time_minutes)
    
    if not labels:
        await message.answer(config.MESSAGES["no_data"], reply_markup=get_admin_keyboard())
        return
    
    # 生成图表
    try:
        plt.figure(figsize=(12, 8))
        plt.bar(labels, values)
        plt.xticks(rotation=45, ha='right')
        plt.ylabel("累计时间(分钟)")
        plt.title("活动时间统计")
        plt.tight_layout()
        
        file_path = f"group_{chat_id}_chart.png"
        plt.savefig(file_path)
        plt.close()
        
        await message.answer_photo(InputFile(file_path), reply_markup=get_admin_keyboard())
    except Exception as e:
        await message.answer(f"❌ 生成图表失败：{e}", reply_markup=get_admin_keyboard())

# ==================== 系统维护功能 ====================
async def daily_reset_task():
    """每日自动重置任务 - 支持自定义重置时间"""
    while True:
        now = datetime.now()
        
        # 为每个群组计算下一次重置时间
        earliest_reset = None
        
        for chat_id_str, chat_data in group_data.items():
            reset_time = chat_data.get("每日重置时间", {"hour": config.DAILY_RESET_HOUR, "minute": config.DAILY_RESET_MINUTE})
            reset_hour = reset_time["hour"]
            reset_minute = reset_time["minute"]
            
            # 计算下一次重置时间
            next_reset = datetime.combine(now.date(), datetime.min.time()) + timedelta(hours=reset_hour, minutes=reset_minute)
            if next_reset <= now:
                next_reset += timedelta(days=1)
            
            if earliest_reset is None or next_reset < earliest_reset:
                earliest_reset = next_reset
        
        # 使用默认重置时间如果没有群组数据
        if earliest_reset is None:
            earliest_reset = datetime.combine(now.date() + timedelta(days=1), datetime.min.time())
        
        wait_seconds = (earliest_reset - now).total_seconds()
        print(f"下一次重置将在 {earliest_reset} 执行，等待 {wait_seconds} 秒")
        
        await asyncio.sleep(wait_seconds)
        
        # 执行重置
        now_after_wait = datetime.now()
        for chat_id_str, chat_data in group_data.items():
            reset_time = chat_data.get("每日重置时间", {"hour": config.DAILY_RESET_HOUR, "minute": config.DAILY_RESET_MINUTE})
            reset_hour = reset_time["hour"]
            reset_minute = reset_time["minute"]
            
            # 检查是否到达该群组的重置时间
            expected_reset = datetime.combine(now_after_wait.date(), datetime.min.time()) + timedelta(hours=reset_hour, minutes=reset_minute)
            if now_after_wait >= expected_reset:
                # 重置该群组的所有用户数据
                for user_data in chat_data["成员"].values():
                    user_data["累计"] = {}
                    user_data["次数"] = {}
                    user_data["总累计时间"] = 0
                    user_data["总次数"] = 0
                    user_data["累计罚款"] = 0
                    user_data["最后更新"] = str(now_after_wait.date())
                
                print(f"{now_after_wait}: 群组 {chat_id_str} 数据重置完成")
        
        save_data()

# ==================== 自动显示按钮 ====================
@dp.message()
async def auto_show_buttons(message: types.Message):
    """自动显示按钮 - 处理所有其他消息"""
    # 如果不是命令或已知消息，显示主键盘
    uid = message.from_user.id
    await message.answer(
        "请使用下方按钮或输入活动名称进行操作：",
        reply_markup=get_main_keyboard(show_admin=is_admin(uid))
    )

# ==================== 启动程序 ====================
async def main():
    """主函数"""
    load_data()
    asyncio.create_task(daily_reset_task())
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())