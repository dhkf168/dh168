import sqlite3
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from config import Config

logger = logging.getLogger("GroupCheckInBot")


class Database:
    def __init__(self, db_path: str = "bot_data.db"):
        self.db_path = db_path
        self.init_database()

    def get_connection(self):
        """获取数据库连接"""
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def init_database(self):
        """初始化数据库表"""
        with self.get_connection() as conn:
            # 群组配置表
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS groups (
                    chat_id INTEGER PRIMARY KEY,
                    channel_id INTEGER,
                    notification_group_id INTEGER,
                    reset_hour INTEGER DEFAULT 0,
                    reset_minute INTEGER DEFAULT 0,
                    work_start_time TEXT DEFAULT '09:00',
                    work_end_time TEXT DEFAULT '18:00',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
            )

            # 用户数据表
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    chat_id INTEGER,
                    user_id INTEGER,
                    nickname TEXT,
                    current_activity TEXT,
                    activity_start_time TEXT,
                    total_accumulated_time INTEGER DEFAULT 0,
                    total_activity_count INTEGER DEFAULT 0,
                    total_fines INTEGER DEFAULT 0,
                    overtime_count INTEGER DEFAULT 0,
                    total_overtime_time INTEGER DEFAULT 0,
                    last_updated DATE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(chat_id, user_id)
                )
            """
            )

            # 用户活动记录表
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS user_activities (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    chat_id INTEGER,
                    user_id INTEGER,
                    activity_date DATE,
                    activity_name TEXT,
                    activity_count INTEGER DEFAULT 0,
                    accumulated_time INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(chat_id, user_id, activity_date, activity_name)
                )
            """
            )

            # 上下班记录表
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS work_records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    chat_id INTEGER,
                    user_id INTEGER,
                    record_date DATE,
                    checkin_type TEXT,
                    checkin_time TEXT,
                    status TEXT,
                    time_diff_minutes REAL,
                    fine_amount INTEGER DEFAULT 0,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(chat_id, user_id, record_date, checkin_type)
                )
            """
            )

            # 活动配置表
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS activity_configs (
                    activity_name TEXT PRIMARY KEY,
                    max_times INTEGER,
                    time_limit INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
            )

            # 罚款配置表
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS fine_configs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    activity_name TEXT,
                    time_segment TEXT,
                    fine_amount INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(activity_name, time_segment)
                )
            """
            )

            # 上下班罚款配置表
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS work_fine_configs (
                    checkin_type TEXT,
                    time_segment TEXT,
                    fine_amount INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(checkin_type, time_segment)
                )
            """
            )

            # 推送配置表
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS push_settings (
                    setting_key TEXT PRIMARY KEY,
                    setting_value INTEGER,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """
            )

            # 初始化默认数据
            self._initialize_default_data(conn)

    def _initialize_default_data(self, conn):
        """初始化默认数据"""
        # 初始化活动配置
        for activity, limits in Config.DEFAULT_ACTIVITY_LIMITS.items():
            conn.execute(
                """
                INSERT OR IGNORE INTO activity_configs (activity_name, max_times, time_limit)
                VALUES (?, ?, ?)
            """,
                (activity, limits["max_times"], limits["time_limit"]),
            )

        # 初始化罚款配置
        for activity, fines in Config.DEFAULT_FINE_RATES.items():
            for time_segment, amount in fines.items():
                conn.execute(
                    """
                    INSERT OR IGNORE INTO fine_configs (activity_name, time_segment, fine_amount)
                    VALUES (?, ?, ?)
                """,
                    (activity, time_segment, amount),
                )

        # 初始化上下班罚款配置
        for checkin_type, fines in Config.DEFAULT_WORK_FINE_RATES.items():
            for time_segment, amount in fines.items():
                conn.execute(
                    """
                    INSERT OR IGNORE INTO work_fine_configs (checkin_type, time_segment, fine_amount)
                    VALUES (?, ?, ?)
                """,
                    (checkin_type, time_segment, amount),
                )

        # 初始化推送设置
        for key, value in Config.AUTO_EXPORT_SETTINGS.items():
            conn.execute(
                """
                INSERT OR IGNORE INTO push_settings (setting_key, setting_value)
                VALUES (?, ?)
            """,
                (key, 1 if value else 0),
            )

        conn.commit()

    def format_seconds_to_hms(self, seconds: int) -> str:
        """将秒数格式化为小时:分钟:秒的字符串"""
        if seconds is None:
            return "0小时0分钟"

        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60

        if hours > 0:
            return f"{hours}小时{minutes}分钟"
        elif minutes > 0:
            return f"{minutes}分钟{secs}秒"
        else:
            return f"{secs}秒"

    def format_minutes_to_hm(self, minutes: float) -> str:
        """将分钟数格式化为小时:分钟的字符串"""
        if minutes is None:
            return "0小时0分钟"

        hours = int(minutes // 60)
        mins = int(minutes % 60)

        return f"{hours}小时{mins}分钟"

    # 群组相关操作
    def get_group(self, chat_id: int) -> Optional[Dict]:
        """获取群组配置"""
        with self.get_connection() as conn:
            row = conn.execute(
                "SELECT * FROM groups WHERE chat_id = ?", (chat_id,)
            ).fetchone()
            return dict(row) if row else None

    def init_group(self, chat_id: int):
        """初始化群组"""
        with self.get_connection() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO groups (chat_id) VALUES (?)
            """,
                (chat_id,),
            )
            conn.commit()

    def update_group_channel(self, chat_id: int, channel_id: int):
        """更新群组频道ID"""
        with self.get_connection() as conn:
            conn.execute(
                """
                UPDATE groups SET channel_id = ?, updated_at = CURRENT_TIMESTAMP
                WHERE chat_id = ?
            """,
                (channel_id, chat_id),
            )
            conn.commit()

    def update_group_notification(self, chat_id: int, group_id: int):
        """更新群组通知群组ID"""
        with self.get_connection() as conn:
            conn.execute(
                """
                UPDATE groups SET notification_group_id = ?, updated_at = CURRENT_TIMESTAMP
                WHERE chat_id = ?
            """,
                (group_id, chat_id),
            )
            conn.commit()

    def update_group_reset_time(self, chat_id: int, hour: int, minute: int):
        """更新群组重置时间"""
        with self.get_connection() as conn:
            conn.execute(
                """
                UPDATE groups SET reset_hour = ?, reset_minute = ?, updated_at = CURRENT_TIMESTAMP
                WHERE chat_id = ?
            """,
                (hour, minute, chat_id),
            )
            conn.commit()

    def update_group_work_time(self, chat_id: int, work_start: str, work_end: str):
        """更新群组上下班时间"""
        with self.get_connection() as conn:
            conn.execute(
                """
                UPDATE groups SET work_start_time = ?, work_end_time = ?, updated_at = CURRENT_TIMESTAMP
                WHERE chat_id = ?
            """,
                (work_start, work_end, chat_id),
            )
            conn.commit()

    def get_group_work_time(self, chat_id: int) -> Dict[str, str]:
        """获取群组上下班时间"""
        with self.get_connection() as conn:
            row = conn.execute(
                "SELECT work_start_time, work_end_time FROM groups WHERE chat_id = ?",
                (chat_id,),
            ).fetchone()
            if row and row["work_start_time"] and row["work_end_time"]:
                return {
                    "work_start": row["work_start_time"],
                    "work_end": row["work_end_time"],
                }
            return Config.DEFAULT_WORK_HOURS.copy()

    def has_work_hours_enabled(self, chat_id: int) -> bool:
        """检查是否启用了上下班功能"""
        work_hours = self.get_group_work_time(chat_id)
        return (
            work_hours["work_start"] != Config.DEFAULT_WORK_HOURS["work_start"]
            and work_hours["work_end"] != Config.DEFAULT_WORK_HOURS["work_end"]
        )

    # 用户相关操作
    def get_user(self, chat_id: int, user_id: int) -> Optional[Dict]:
        """获取用户数据"""
        with self.get_connection() as conn:
            row = conn.execute(
                """
                SELECT * FROM users WHERE chat_id = ? AND user_id = ?
            """,
                (chat_id, user_id),
            ).fetchone()
            return dict(row) if row else None

    def init_user(self, chat_id: int, user_id: int, nickname: str = None):
        """初始化用户"""
        today = str(datetime.now().date())
        with self.get_connection() as conn:
            # 检查用户是否已存在
            existing_user = conn.execute(
                "SELECT 1 FROM users WHERE chat_id = ? AND user_id = ?",
                (chat_id, user_id),
            ).fetchone()

            if not existing_user:
                conn.execute(
                    """
                    INSERT INTO users (chat_id, user_id, nickname, last_updated)
                    VALUES (?, ?, ?, ?)
                """,
                    (chat_id, user_id, nickname, today),
                )
                conn.commit()

    def update_user_activity(
        self,
        chat_id: int,
        user_id: int,
        activity: str = None,
        start_time: str = None,
        nickname: str = None,
    ):
        """更新用户活动状态"""
        with self.get_connection() as conn:
            update_fields = []
            params = []

            if activity is not None:
                update_fields.append("current_activity = ?")
                params.append(activity)

            if start_time is not None:
                update_fields.append("activity_start_time = ?")
                params.append(start_time)

            if nickname is not None:
                update_fields.append("nickname = ?")
                params.append(nickname)

            update_fields.append("updated_at = CURRENT_TIMESTAMP")

            params.extend([chat_id, user_id])

            query = f"""
                UPDATE users SET {', '.join(update_fields)}
                WHERE chat_id = ? AND user_id = ?
            """
            conn.execute(query, params)
            conn.commit()

    def complete_user_activity(
        self,
        chat_id: int,
        user_id: int,
        activity: str,
        elapsed_time: int,
        fine_amount: int = 0,
        is_overtime: bool = False,
    ):
        """完成用户活动"""
        today = str(datetime.now().date())
        with self.get_connection() as conn:
            # 更新用户活动记录
            conn.execute(
                """
                INSERT OR REPLACE INTO user_activities 
                (chat_id, user_id, activity_date, activity_name, activity_count, accumulated_time)
                VALUES (?, ?, ?, ?, 
                COALESCE((SELECT activity_count FROM user_activities 
                         WHERE chat_id = ? AND user_id = ? AND activity_date = ? AND activity_name = ?), 0) + 1,
                COALESCE((SELECT accumulated_time FROM user_activities 
                         WHERE chat_id = ? AND user_id = ? AND activity_date = ? AND activity_name = ?), 0) + ?)
            """,
                (
                    chat_id,
                    user_id,
                    today,
                    activity,
                    chat_id,
                    user_id,
                    today,
                    activity,
                    chat_id,
                    user_id,
                    today,
                    activity,
                    elapsed_time,
                ),
            )

            # 更新用户总数据
            update_fields = []
            params = []

            update_fields.append("total_accumulated_time = total_accumulated_time + ?")
            params.append(elapsed_time)

            update_fields.append("total_activity_count = total_activity_count + 1")

            if fine_amount > 0:
                update_fields.append("total_fines = total_fines + ?")
                params.append(fine_amount)

            if is_overtime:
                update_fields.append("overtime_count = overtime_count + 1")
                overtime_seconds = max(
                    0, elapsed_time - (self.get_activity_time_limit(activity) * 60)
                )
                update_fields.append("total_overtime_time = total_overtime_time + ?")
                params.append(overtime_seconds)

            update_fields.append("last_updated = ?")
            params.append(today)

            update_fields.append("current_activity = NULL")
            update_fields.append("activity_start_time = NULL")

            params.extend([chat_id, user_id])

            query = f"""
                UPDATE users SET {', '.join(update_fields)}
                WHERE chat_id = ? AND user_id = ?
            """
            conn.execute(query, params)
            conn.commit()

    def reset_user_daily_data(self, chat_id: int, user_id: int):
        """重置用户每日数据"""
        today = str(datetime.now().date())
        with self.get_connection() as conn:
            # 删除今日活动记录
            conn.execute(
                """
                DELETE FROM user_activities 
                WHERE chat_id = ? AND user_id = ? AND activity_date = ?
            """,
                (chat_id, user_id, today),
            )

            # 重置用户数据
            conn.execute(
                """
                UPDATE users SET 
                total_accumulated_time = 0,
                total_activity_count = 0,
                total_fines = 0,
                overtime_count = 0,
                total_overtime_time = 0,
                last_updated = ?
                WHERE chat_id = ? AND user_id = ?
            """,
                (today, chat_id, user_id),
            )
            conn.commit()

    def get_user_activity_count(self, chat_id: int, user_id: int, activity: str) -> int:
        """获取用户今日活动次数"""
        today = str(datetime.now().date())
        with self.get_connection() as conn:
            row = conn.execute(
                """
                SELECT activity_count FROM user_activities 
                WHERE chat_id = ? AND user_id = ? AND activity_date = ? AND activity_name = ?
            """,
                (chat_id, user_id, today, activity),
            ).fetchone()
            return row["activity_count"] if row else 0

    def get_user_activity_time(self, chat_id: int, user_id: int, activity: str) -> int:
        """获取用户今日活动累计时间"""
        today = str(datetime.now().date())
        with self.get_connection() as conn:
            row = conn.execute(
                """
                SELECT accumulated_time FROM user_activities 
                WHERE chat_id = ? AND user_id = ? AND activity_date = ? AND activity_name = ?
            """,
                (chat_id, user_id, today, activity),
            ).fetchone()
            return row["accumulated_time"] if row else 0

    def get_user_all_activities(self, chat_id: int, user_id: int) -> Dict[str, Dict]:
        """获取用户所有活动数据"""
        today = str(datetime.now().date())
        with self.get_connection() as conn:
            rows = conn.execute(
                """
                SELECT activity_name, activity_count, accumulated_time 
                FROM user_activities 
                WHERE chat_id = ? AND user_id = ? AND activity_date = ?
            """,
                (chat_id, user_id, today),
            ).fetchall()

            activities = {}
            for row in rows:
                activities[row["activity_name"]] = {
                    "count": row["activity_count"],
                    "time": row["accumulated_time"],
                    "time_formatted": self.format_seconds_to_hms(
                        row["accumulated_time"]
                    ),
                }
            return activities

    # 上下班记录操作
    def add_work_record(
        self,
        chat_id: int,
        user_id: int,
        record_date: str,
        checkin_type: str,
        checkin_time: str,
        status: str,
        time_diff_minutes: float,
        fine_amount: int = 0,
    ):
        """添加上下班记录"""
        with self.get_connection() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO work_records 
                (chat_id, user_id, record_date, checkin_type, checkin_time, status, time_diff_minutes, fine_amount)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    chat_id,
                    user_id,
                    record_date,
                    checkin_type,
                    checkin_time,
                    status,
                    time_diff_minutes,
                    fine_amount,
                ),
            )

            if fine_amount > 0:
                conn.execute(
                    """
                    UPDATE users SET total_fines = total_fines + ?
                    WHERE chat_id = ? AND user_id = ?
                """,
                    (fine_amount, chat_id, user_id),
                )

            conn.commit()

    def get_user_work_records(
        self, chat_id: int, user_id: int, limit: int = 7
    ) -> List[Dict]:
        """获取用户上下班记录"""
        with self.get_connection() as conn:
            rows = conn.execute(
                """
                SELECT * FROM work_records 
                WHERE chat_id = ? AND user_id = ?
                ORDER BY record_date DESC, checkin_type
                LIMIT ?
            """,
                (chat_id, user_id, limit * 2),
            ).fetchall()

            result = []
            for row in rows:
                record = dict(row)
                # 格式化时间差
                if record["time_diff_minutes"]:
                    record["time_diff_formatted"] = self.format_minutes_to_hm(
                        record["time_diff_minutes"]
                    )
                else:
                    record["time_diff_formatted"] = "0小时0分钟"
                result.append(record)

            return result

    def has_work_record_today(
        self, chat_id: int, user_id: int, checkin_type: str
    ) -> bool:
        """检查今天是否有指定类型的上下班记录"""
        today = str(datetime.now().date())
        with self.get_connection() as conn:
            row = conn.execute(
                """
                SELECT 1 FROM work_records 
                WHERE chat_id = ? AND user_id = ? AND record_date = ? AND checkin_type = ?
            """,
                (chat_id, user_id, today, checkin_type),
            ).fetchone()
            return row is not None

    def get_today_work_records(self, chat_id: int, user_id: int) -> Dict[str, Dict]:
        """获取用户今天的上下班记录"""
        today = str(datetime.now().date())
        with self.get_connection() as conn:
            rows = conn.execute(
                """
                SELECT * FROM work_records 
                WHERE chat_id = ? AND user_id = ? AND record_date = ?
            """,
                (chat_id, user_id, today),
            ).fetchall()

            records = {}
            for row in rows:
                record = dict(row)
                # 格式化时间差
                if record["time_diff_minutes"]:
                    record["time_diff_formatted"] = self.format_minutes_to_hm(
                        record["time_diff_minutes"]
                    )
                else:
                    record["time_diff_formatted"] = "0小时0分钟"
                records[row["checkin_type"]] = record
            return records

    # 活动配置操作
    def get_activity_limits(self) -> Dict:
        """获取所有活动限制"""
        with self.get_connection() as conn:
            rows = conn.execute("SELECT * FROM activity_configs").fetchall()
            return {
                row["activity_name"]: {
                    "max_times": row["max_times"],
                    "time_limit": row["time_limit"],
                }
                for row in rows
            }

    def get_activity_time_limit(self, activity: str) -> int:
        """获取活动时间限制"""
        with self.get_connection() as conn:
            row = conn.execute(
                "SELECT time_limit FROM activity_configs WHERE activity_name = ?",
                (activity,),
            ).fetchone()
            return row["time_limit"] if row else 0

    def get_activity_max_times(self, activity: str) -> int:
        """获取活动最大次数"""
        with self.get_connection() as conn:
            row = conn.execute(
                "SELECT max_times FROM activity_configs WHERE activity_name = ?",
                (activity,),
            ).fetchone()
            return row["max_times"] if row else 0

    def update_activity_config(self, activity: str, max_times: int, time_limit: int):
        """更新活动配置"""
        with self.get_connection() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO activity_configs (activity_name, max_times, time_limit)
                VALUES (?, ?, ?)
            """,
                (activity, max_times, time_limit),
            )
            conn.commit()

    def delete_activity_config(self, activity: str):
        """删除活动配置"""
        with self.get_connection() as conn:
            conn.execute(
                "DELETE FROM activity_configs WHERE activity_name = ?", (activity,)
            )
            conn.execute(
                "DELETE FROM fine_configs WHERE activity_name = ?", (activity,)
            )
            conn.commit()

    def activity_exists(self, activity: str) -> bool:
        """检查活动是否存在"""
        with self.get_connection() as conn:
            row = conn.execute(
                "SELECT 1 FROM activity_configs WHERE activity_name = ?", (activity,)
            ).fetchone()
            return row is not None

    # 罚款配置操作
    def get_fine_rates(self) -> Dict:
        """获取所有罚款费率"""
        with self.get_connection() as conn:
            rows = conn.execute("SELECT * FROM fine_configs").fetchall()
            fines = {}
            for row in rows:
                activity = row["activity_name"]
                if activity not in fines:
                    fines[activity] = {}
                fines[activity][row["time_segment"]] = row["fine_amount"]
            return fines

    def get_fine_rates_for_activity(self, activity: str) -> Dict:
        """获取指定活动的罚款费率"""
        with self.get_connection() as conn:
            rows = conn.execute(
                "SELECT time_segment, fine_amount FROM fine_configs WHERE activity_name = ?",
                (activity,),
            ).fetchall()
            return {row["time_segment"]: row["fine_amount"] for row in rows}

    def update_fine_config(self, activity: str, time_segment: str, fine_amount: int):
        """更新罚款配置"""
        with self.get_connection() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO fine_configs (activity_name, time_segment, fine_amount)
                VALUES (?, ?, ?)
            """,
                (activity, time_segment, fine_amount),
            )
            conn.commit()

    def get_work_fine_rates(self) -> Dict:
        """获取上下班罚款费率"""
        with self.get_connection() as conn:
            rows = conn.execute("SELECT * FROM work_fine_configs").fetchall()
            fines = {}
            for row in rows:
                checkin_type = row["checkin_type"]
                if checkin_type not in fines:
                    fines[checkin_type] = {}
                fines[checkin_type][row["time_segment"]] = row["fine_amount"]
            return fines

    def get_work_fine_rates_for_type(self, checkin_type: str) -> Dict:
        """获取指定类型的上下班罚款费率"""
        with self.get_connection() as conn:
            rows = conn.execute(
                "SELECT time_segment, fine_amount FROM work_fine_configs WHERE checkin_type = ?",
                (checkin_type,),
            ).fetchall()
            return {row["time_segment"]: row["fine_amount"] for row in rows}

    def update_work_fine_config(
        self, checkin_type: str, time_segment: str, fine_amount: int
    ):
        """更新上下班罚款配置"""
        with self.get_connection() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO work_fine_configs (checkin_type, time_segment, fine_amount)
                VALUES (?, ?, ?)
            """,
                (checkin_type, time_segment, fine_amount),
            )
            conn.commit()

    # 推送设置操作
    def get_push_settings(self) -> Dict:
        """获取推送设置"""
        with self.get_connection() as conn:
            rows = conn.execute("SELECT * FROM push_settings").fetchall()
            return {row["setting_key"]: bool(row["setting_value"]) for row in rows}

    def update_push_setting(self, key: str, value: bool):
        """更新推送设置"""
        with self.get_connection() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO push_settings (setting_key, setting_value)
                VALUES (?, ?)
            """,
                (key, 1 if value else 0),
            )
            conn.commit()

    # 统计和导出相关
    def get_group_statistics(self, chat_id: int) -> List[Dict]:
        """获取群组统计信息"""
        today = str(datetime.now().date())
        with self.get_connection() as conn:
            # 获取所有用户的基本统计
            users = conn.execute(
                """
                SELECT user_id, nickname, total_accumulated_time, total_activity_count,
                       total_fines, overtime_count, total_overtime_time
                FROM users 
                WHERE chat_id = ? AND last_updated = ?
            """,
                (chat_id, today),
            ).fetchall()

            result = []
            for user in users:
                user_data = dict(user)

                # 格式化时间
                user_data["total_accumulated_time_formatted"] = (
                    self.format_seconds_to_hms(user_data["total_accumulated_time"])
                )
                user_data["total_overtime_time_formatted"] = self.format_seconds_to_hms(
                    user_data["total_overtime_time"]
                )

                # 获取用户的活动详情
                activities = conn.execute(
                    """
                    SELECT activity_name, activity_count, accumulated_time
                    FROM user_activities
                    WHERE chat_id = ? AND user_id = ? AND activity_date = ?
                """,
                    (chat_id, user["user_id"], today),
                ).fetchall()

                user_data["activities"] = {}
                for row in activities:
                    user_data["activities"][row["activity_name"]] = {
                        "count": row["activity_count"],
                        "time": row["accumulated_time"],
                        "time_formatted": self.format_seconds_to_hms(
                            row["accumulated_time"]
                        ),
                    }

                result.append(user_data)

            return result

    def get_all_groups(self) -> List[int]:
        """获取所有群组ID"""
        with self.get_connection() as conn:
            rows = conn.execute("SELECT chat_id FROM groups").fetchall()
            return [row["chat_id"] for row in rows]

    def get_group_members(self, chat_id: int) -> List[Dict]:
        """获取群组成员"""
        today = str(datetime.now().date())
        with self.get_connection() as conn:
            rows = conn.execute(
                """
                SELECT user_id, nickname, current_activity, activity_start_time,
                       total_accumulated_time, total_activity_count, total_fines,
                       overtime_count, total_overtime_time
                FROM users 
                WHERE chat_id = ? AND last_updated = ?
            """,
                (chat_id, today),
            ).fetchall()

            result = []
            for row in rows:
                user_data = dict(row)
                # 格式化时间
                user_data["total_accumulated_time_formatted"] = (
                    self.format_seconds_to_hms(user_data["total_accumulated_time"])
                )
                user_data["total_overtime_time_formatted"] = self.format_seconds_to_hms(
                    user_data["total_overtime_time"]
                )
                result.append(user_data)

            return result

    # 数据清理
    def cleanup_old_data(self, days: int = 30):
        """清理旧数据"""
        cutoff_date = (datetime.now() - timedelta(days=days)).date()
        with self.get_connection() as conn:
            # 清理旧的活动记录
            conn.execute(
                """
                DELETE FROM user_activities WHERE activity_date < ?
            """,
                (str(cutoff_date),),
            )

            # 清理旧的上下班记录
            conn.execute(
                """
                DELETE FROM work_records WHERE record_date < ?
            """,
                (str(cutoff_date),),
            )

            # 清理长时间未更新的用户数据
            conn.execute(
                """
                DELETE FROM users WHERE last_updated < ?
            """,
                (str(cutoff_date),),
            )

            conn.commit()

    def get_database_size(self) -> int:
        """获取数据库大小"""
        import os

        if os.path.exists(self.db_path):
            return os.path.getsize(self.db_path)
        return 0

    def get_monthly_statistics(
        self, chat_id: int, year: int = None, month: int = None
    ) -> List[Dict]:
        """获取月度统计信息"""
        if year is None or month is None:
            today = datetime.now()
            year = today.year
            month = today.month

        start_date = f"{year:04d}-{month:02d}-01"
        if month == 12:
            end_date = f"{year+1:04d}-01-01"
        else:
            end_date = f"{year:04d}-{month+1:02d}-01"

        with self.get_connection() as conn:
            # 获取月度活动统计
            monthly_stats = conn.execute(
                """
                SELECT 
                    u.user_id,
                    u.nickname,
                    SUM(COALESCE(ua.accumulated_time, 0)) as total_time,
                    SUM(COALESCE(ua.activity_count, 0)) as total_count,
                    SUM(COALESCE(u.total_fines, 0)) as total_fines,
                    SUM(COALESCE(u.overtime_count, 0)) as total_overtime_count,
                    SUM(COALESCE(u.total_overtime_time, 0)) as total_overtime_time
                FROM users u
                LEFT JOIN user_activities ua ON u.chat_id = ua.chat_id AND u.user_id = ua.user_id
                    AND ua.activity_date >= ? AND ua.activity_date < ?
                WHERE u.chat_id = ?
                GROUP BY u.user_id, u.nickname
                ORDER BY total_time DESC
            """,
                (start_date, end_date, chat_id),
            ).fetchall()

            result = []
            for stat in monthly_stats:
                user_data = dict(stat)

                # 确保所有时间字段都有值
                user_data["total_time"] = user_data["total_time"] or 0
                user_data["total_overtime_time"] = user_data["total_overtime_time"] or 0

                # 转换时间为小时和分钟格式 - 这里改为直接存储格式化字符串
                user_data["total_time"] = self.format_seconds_to_hms(
                    user_data["total_time"]
                )
                user_data["total_overtime_time"] = self.format_seconds_to_hms(
                    user_data["total_overtime_time"]
                )

                # 获取用户每项活动的详细统计
                activity_details = conn.execute(
                    """
                    SELECT 
                        activity_name,
                        SUM(activity_count) as activity_count,
                        SUM(accumulated_time) as accumulated_time
                    FROM user_activities
                    WHERE chat_id = ? AND user_id = ? AND activity_date >= ? AND activity_date < ?
                    GROUP BY activity_name
                """,
                    (chat_id, user_data["user_id"], start_date, end_date),
                ).fetchall()

                user_data["activities"] = {}
                for row in activity_details:
                    activity_time = row["accumulated_time"] or 0
                    user_data["activities"][row["activity_name"]] = {
                        "count": row["activity_count"] or 0,
                        "time": self.format_seconds_to_hms(
                            activity_time
                        ),  # 直接存储格式化字符串
                    }

                result.append(user_data)

            return result

    def get_monthly_work_statistics(
        self, chat_id: int, year: int = None, month: int = None
    ) -> List[Dict]:
        """获取月度上下班统计"""
        if year is None or month is None:
            today = datetime.now()
            year = today.year
            month = today.month

        start_date = f"{year:04d}-{month:02d}-01"
        if month == 12:
            end_date = f"{year+1:04d}-01-01"
        else:
            end_date = f"{year:04d}-{month+1:02d}-01"

        with self.get_connection() as conn:
            rows = conn.execute(
                """
                SELECT 
                    wr.user_id,
                    u.nickname,
                    COUNT(CASE WHEN wr.checkin_type = 'work_start' THEN 1 END) as work_start_count,
                    COUNT(CASE WHEN wr.checkin_type = 'work_end' THEN 1 END) as work_end_count,
                    SUM(CASE WHEN wr.checkin_type = 'work_start' THEN wr.fine_amount ELSE 0 END) as work_start_fines,
                    SUM(CASE WHEN wr.checkin_type = 'work_end' THEN wr.fine_amount ELSE 0 END) as work_end_fines,
                    AVG(CASE WHEN wr.checkin_type = 'work_start' THEN wr.time_diff_minutes ELSE NULL END) as avg_work_start_late,
                    AVG(CASE WHEN wr.checkin_type = 'work_end' THEN wr.time_diff_minutes ELSE NULL END) as avg_work_end_early
                FROM work_records wr
                JOIN users u ON wr.chat_id = u.chat_id AND wr.user_id = u.user_id
                WHERE wr.chat_id = ? AND wr.record_date >= ? AND wr.record_date < ?
                GROUP BY wr.user_id, u.nickname
                ORDER BY work_start_count DESC, work_end_count DESC
            """,
                (chat_id, start_date, end_date),
            ).fetchall()

            result = []
            for row in rows:
                user_data = dict(row)

                # 确保时间字段有值
                user_data["avg_work_start_late"] = user_data["avg_work_start_late"] or 0
                user_data["avg_work_end_early"] = user_data["avg_work_end_early"] or 0

                # 格式化迟到/早退时间为小时分钟
                user_data["avg_work_start_late_formatted"] = self.format_minutes_to_hm(
                    user_data["avg_work_start_late"]
                )
                user_data["avg_work_end_early_formatted"] = self.format_minutes_to_hm(
                    user_data["avg_work_end_early"]
                )

                result.append(user_data)

            return result

    def get_monthly_activity_ranking(
        self, chat_id: int, year: int = None, month: int = None
    ) -> Dict[str, List]:
        """获取月度活动排行榜"""
        if year is None or month is None:
            today = datetime.now()
            year = today.year
            month = today.month

        start_date = f"{year:04d}-{month:02d}-01"
        if month == 12:
            end_date = f"{year+1:04d}-01-01"
        else:
            end_date = f"{year:04d}-{month+1:02d}-01"

        with self.get_connection() as conn:
            activity_limits = self.get_activity_limits()
            rankings = {}

            for activity in activity_limits.keys():
                rows = conn.execute(
                    """
                    SELECT 
                        u.user_id,
                        u.nickname,
                        SUM(COALESCE(ua.accumulated_time, 0)) as total_time,
                        SUM(COALESCE(ua.activity_count, 0)) as total_count
                    FROM user_activities ua
                    JOIN users u ON ua.chat_id = u.chat_id AND ua.user_id = u.user_id
                    WHERE ua.chat_id = ? AND ua.activity_name = ? AND ua.activity_date >= ? AND ua.activity_date < ?
                    GROUP BY u.user_id, u.nickname
                    ORDER BY total_time DESC
                    LIMIT 10
                """,
                    (chat_id, activity, start_date, end_date),
                ).fetchall()

                formatted_rows = []
                for row in rows:
                    user_data = dict(row)
                    # 确保时间字段有值
                    user_data["total_time"] = user_data["total_time"] or 0
                    # 格式化时间为小时分钟
                    user_data["total_time_formatted"] = self.format_seconds_to_hms(
                        user_data["total_time"]
                    )
                    formatted_rows.append(user_data)

                rankings[activity] = formatted_rows

            return rankings
